UNSIGNED APK: MUST be signed locally with privately held durable key before installation.
