$ErrorActionPreference = 'Stop'
# Installs a previously CI-built portable EXE without administrator permission or Python.
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $here 'BlessingBookHarvester.exe'
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw "Executable absent : BlessingBookHarvester.exe. Utiliser l'archive Windows produite par GitHub Actions." }
$target = Join-Path $env:LOCALAPPDATA 'BlessingBookHarvester'
New-Item -ItemType Directory -Path $target -Force | Out-Null
$binary = Join-Path $target 'BlessingBookHarvester.exe'
Copy-Item -LiteralPath $exe -Destination $binary -Force
$probe = Join-Path $target 'self-test.json'
$process = Start-Process -FilePath $binary -ArgumentList @('--self-test','--self-test-report',('"'+$probe+'"')) -PassThru -Wait
if ($process.ExitCode -ne 0 -or !(Test-Path -LiteralPath $probe)) { throw 'Auto-test echec: raccourci non cree. Verifier antivirus ou protection Windows.' }
$report = Get-Content -Raw -LiteralPath $probe | ConvertFrom-Json
if (-not $report.ok) { throw 'Dependances absentes dans le binaire.' }
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Blessing BookHarvester.lnk'))
$shortcut.TargetPath = $binary
$shortcut.WorkingDirectory = $target
$shortcut.Description = 'Blessing BookHarvester (livres autorises, local)'
$shortcut.Save()
Write-Output ('INSTALLED: ' + $binary)
Write-Output ('SHORTCUT: ' + (Join-Path $desktop 'Blessing BookHarvester.lnk'))
