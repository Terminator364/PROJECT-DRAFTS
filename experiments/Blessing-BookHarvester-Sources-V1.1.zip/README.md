# Blessing BookHarvester V1.1 — QA candidate

**Purpose:** lightweight Windows personal reading archiver for books/pages that you are authorised to copy. Download chapters sequentially; resume after interruption; detect missing/duplicate/corrupt entries; export text novels to **EPUB/PDF**, comic images to **CBZ**. Not an anti-bot / CAPTCHA / paywall bypass tool.

> **Certification status: NOT YET VALIDATED ON WINDOWS OR RANOVEL.** The local offline test suite has 23 passing tests. The Windows GitHub Actions workflow will build, install, and smoke-test the **portable EXE**. Live Ranovel chapter extraction still requires its own verified test: a 403 response must stop collection and must never be treated as success.

## One-time Windows installation (only after CI passes)

1. Download artifact `Blessing-BookHarvester-Windows-V1.1` from the successful GitHub Actions run.
2. Extract the ZIP to a folder.
3. Double-click `Install-Portable.bat`. No Python, administrator account or additional permanent services required. It installs into `%LOCALAPPDATA%\BlessingBookHarvester` and creates a **Blessing BookHarvester** desktop shortcut.
4. Double-click the shortcut. Paste the URL of a text novel or manga. Verify the chapter count or use discovery. Click **Télécharger / Reprendre**.

The app stores its books at `%USERPROFILE%\Documents\Blessing BookHarvester`. The EXE never uploads your books. First launch may be screened by Windows SmartScreen because this unsigned prototype is not code-signed.

## What counts as complete?

If the source lists 236 chapters, put **236** in the total field. Export to PDF/EPUB is refused if any of those 236 are missing, failed or identified as duplicate/corrupt. A catalogue of 24 imported chapters with expected total 236 is **incomplete**. An unsupported website or access restriction is explicitly reported, never hidden by automatic bypass.

**Attention:** automatic URLs such as `chapter-{n}/` are just hypotheses. Some sites use different routes or JavaScript. A generic extractor cannot promise success for every source; the production plan is one approved profile per verified site.

## Advanced CLI / offline tests

Python source is included for review. Python 3.10+ and `pip install -r requirements.txt` are needed **only to run the source**; not the portable EXE.

```powershell
py -3 bookharvester.py --self-test
py -3 bookharvester.py --book "Sample" --expect 236 --check
py -3 bookharvester.py --book "Sample" --expect 236 --import-html C:\SavedChapters
py -3 bookharvester.py --book "Sample" --export pdf
py -3 -m pytest -q tests
```

Sample scripts and tests only use **synthetic** text; no copyrighted novels are bundled.

## Technical inventory

- Python standard-library `urllib`, `sqlite3` persistence, BeautifulSoup for HTML parsing, ReportLab for PDF, EPUB3 ZIP and CBZ ZIP exports.
- All processing is local; max 15MB per fetched page; requests spaced; blocked HTTP 401/403/407/429/451 are stopped with explicit errors.
- Windows portable build by PyInstaller (`--onefile --windowed`), PowerShell installer copies under `%LOCALAPPDATA%`, self-tests the EXE, creates desktop shortcut with COM API.
- QA: 23 local pytest tests including synthetic 236-chapter end-to-end EPUB generation, interrupted download/resume, MHTML, unicode, PDF contents, CBZ image hashes, duplicate checks, blocked access.
- GitHub Actions one targeted Windows job: setup, pytest, PyInstaller, EXE self-test and minimal Tk UI probe, one-click installation smoke, shortcut target, release artifact SHA256.

## Known limitations

- No login/captcha/paywall bypass and no JavaScript SPA rendering.
- Site connectors not universal. Ranovel access from external environments has returned 403; it is **not** a validated supported source.
- Manga exports to CBZ (images), not PDF.
- Unsigned portable EXE may trigger SmartScreen; some antivirus software may quarantine packed executables. Manual Windows acceptance, if trusted, may be required.
- Retain the `Documents\Blessing BookHarvester` data directory when upgrading.

## Independent references

- [lncrawl/lightnovel-crawler](https://github.com/lncrawl/lightnovel-crawler)
- [Flameish/Novel-Grabber](https://github.com/Flameish/Novel-Grabber)
- [manga-download/hakuneko](https://github.com/manga-download/hakuneko)
