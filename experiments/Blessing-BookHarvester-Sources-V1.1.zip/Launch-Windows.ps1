$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
if(Get-Command py -ErrorAction SilentlyContinue) { & py -3 (Join-Path $here 'bookharvester.py') --gui }
else { & python (Join-Path $here 'bookharvester.py') --gui }
if ($LASTEXITCODE -ne 0) { Write-Host 'Echec du lancement; verifier Python/les dependances.'; Read-Host 'Appuyer Entree pour fermer' }
