$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = $null
if (Get-Command py -ErrorAction SilentlyContinue) { $python = 'py'; $argPrefix=@('-3') }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $python = 'python'; $argPrefix=@() }
else { Write-Host 'Python 3.10+ non trouve. Installer depuis https://www.python.org/downloads/windows/ et relancer.'; Read-Host 'Entree pour fermer'; exit 2 }
& $python @argPrefix -m pip install -r (Join-Path $here 'requirements.txt')
if ($LASTEXITCODE -ne 0) { Write-Host 'Dependencies non installees. Verifier Internet puis relancer.'; Read-Host 'Entree pour fermer'; exit 3 }
$desktop=[Environment]::GetFolderPath('Desktop')
$shortcut=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Blessing BookHarvester.lnk'))
$shortcut.TargetPath='powershell.exe'
$script=Join-Path $here 'Launch-Windows.ps1'
$shortcut.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$script+'"'
$shortcut.WorkingDirectory=$here
$shortcut.Description='Lancer Blessing BookHarvester (bibliotheque locale)'
$shortcut.Save()
Write-Host ('Raccourci cree : ' + (Join-Path $desktop 'Blessing BookHarvester.lnk'))
Read-Host 'Appuyer Entree pour fermer'
