"""Import a reader-authorized Microsoft Edge extension collection into SQLite.

Input JSON stays on the user's own machine. The extension doesn't bypass access
controls and never contacts our servers. No internet is needed for importing.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

FORMAT = "blessing-bookharvester-edge-v1"
MAX_FILE_BYTES = 72 * 1024 * 1024
MAX_CHAPTER_BYTES = 2 * 1024 * 1024


class EdgeImportError(ValueError):
    pass


def import_edge_bundle(path: Path, root: Path, expected_book: str | None = None) -> dict:
    from bookharvester import Catalog, check_url, inventory

    path = Path(path)
    if not path.is_file() or path.stat().st_size > MAX_FILE_BYTES:
        raise EdgeImportError("Fichier Edge absent ou trop volumineux (limite 72 Mo)")
    try:
        bundle = json.loads(path.read_text(encoding="utf-8-sig"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise EdgeImportError("Le fichier reçu n'est pas un export Edge JSON valide") from exc
    if not isinstance(bundle, dict) or bundle.get("schema") != FORMAT:
        raise EdgeImportError("Format d'export Edge non reconnu")
    book = bundle.get("book")
    if not isinstance(book, str) or not 1 <= len(book.strip()) <= 180:
        raise EdgeImportError("Titre du livre absent ou invalide")
    book = book.strip()
    if expected_book is not None and expected_book != book:
        raise EdgeImportError("Le titre choisi ne correspond pas à celui du fichier Edge")
    origin = bundle.get("origin")
    if not isinstance(origin, str):
        raise EdgeImportError("Origine du site manquante")
    check_url(origin)
    origin_parsed = urlsplit(origin)
    if origin_parsed.path not in ("", "/") or origin_parsed.query or origin_parsed.fragment:
        raise EdgeImportError("Origine du site invalide")
    chapters = bundle.get("chapters")
    if not isinstance(chapters, list) or len(chapters) > 20000:
        raise EdgeImportError("Liste de chapitres invalide")
    expected = bundle.get("expected_end", 0)
    if type(expected) is not int or not 1 <= expected <= 20000:
        raise EdgeImportError("Nombre de chapitres attendu invalide")
    validated = []
    seen = set()
    for record in chapters:
        if not isinstance(record, dict):
            raise EdgeImportError("Chapitre non structuré")
        n, title, text, source_url = (record.get(k) for k in ("number", "title", "text", "url"))
        if type(n) is not int or not 1 <= n <= expected or n in seen:
            raise EdgeImportError(f"Numéro manquant, répété ou hors collection : {n}")
        seen.add(n)
        if not isinstance(title, str) or len(title) > 500:
            raise EdgeImportError(f"Titre invalide au chapitre {n}")
        if not isinstance(text, str) or len(text.strip()) < 100 or len(text.encode('utf-8')) > MAX_CHAPTER_BYTES:
            raise EdgeImportError(f"Texte insuffisant ou trop volumineux au chapitre {n}")
        if not isinstance(source_url, str):
            raise EdgeImportError(f"URL absente au chapitre {n}")
        check_url(source_url)
        site = urlsplit(source_url)
        if (site.scheme.lower(), site.netloc.lower()) != (origin_parsed.scheme.lower(), origin_parsed.netloc.lower()):
            raise EdgeImportError(f"Origine étrangère au chapitre {n}")
        sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
        digest_from_file = record.get("sha256")
        if digest_from_file is not None and digest_from_file != sha:
            raise EdgeImportError(f"Contrôle SHA-256 échoué au chapitre {n}")
        validated.append((n, title, text, source_url, sha))
    if not validated:
        raise EdgeImportError("Aucun chapitre à importer")
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    cat = Catalog(root / "library.sqlite3")
    imported, skipped, conflicts = [], [], []
    try:
        cat.plan(book, [(n,url) for n,title,text,url,sha in validated], "novel", expected_end=expected)
        previous = {r[0]:r for r in cat.chapters(book)}
        for n,title,text,url,sha in validated:
            earlier=previous.get(n)
            if earlier and earlier[5]=="ok":
                if earlier[6]==sha:
                    skipped.append(n)
                else:
                    conflicts.append(n)
                continue
            cat.complete(book,n,title,text,"novel",sha)
            imported.append(n)
        inv = inventory(cat,book)
    finally:
        cat.close()
    return {"book":book,"imported":imported,"already_present":skipped,"conflicts":conflicts,"inventory":inv}
