/* Runs on already accessible tabs in Edge. Never performs a network request. */
(() => {
  globalThis.BH_READ_PAGE = function readPage(extraSelectors = []) {
    const blocked = /access denied|forbidden|verify you are human|just a moment|captcha|checking your browser|403 forbidden|cloudflare challenge/i;
    const pageTitle = document.title || '';
    const topText = (document.body && (document.body.innerText || document.body.textContent) || '').slice(0, 1200);
    if (blocked.test(pageTitle) || blocked.test(topText.slice(0, 350))) {
      return {ok:false,error:'ACCÈS REFUSÉ : contrôle ou blocage du site détecté'};
    }
    const defaults = ['.reading-content','.chapter-content','#chapter-content','.chapter-reading','.entry-content','.read-content','.text_story','.chapter-body','.chapter-text','.wp-manga-chapter','article','main'];
    const selectors = [...new Set([...extraSelectors.filter(s => typeof s === 'string' && s.length < 160), ...defaults])];
    const candidates = [];
    for (const selector of selectors) {
      let elements = [];
      try { elements = [...document.querySelectorAll(selector)]; } catch (e) { continue; }
      for (const el of elements) {
        if (!el) continue;
        const node = el.cloneNode(true);
        node.querySelectorAll('script,style,noscript,iframe,nav,aside,form,footer,header,button,.ads,.advertisement,.adsbygoogle,.chapter-nav,.ad-container').forEach(x => x.remove());
        const ps = [...node.querySelectorAll('p')].map(p => (p.textContent || '').replace(/\s+/g,' ').trim()).filter(Boolean);
        let text;
        if (ps.length >= 2 && ps.join(' ').length > 130) {
          text = ps.join('\n\n');
        } else {
          node.querySelectorAll('br').forEach(b => b.replaceWith('\n'));
          const blocks = [...node.querySelectorAll('div,h2,h3,li')];
          for (const block of blocks) {
            if (block.childNodes.length===1 && block.firstChild.nodeType===Node.TEXT_NODE) block.appendChild(document.createTextNode('\n'));
          }
          text = (node.textContent || '').replace(/\r/g,'').replace(/[ \t]+/g,' ').replace(/\n\s*\n\s*\n+/g,'\n\n').trim();
        }
        if (text.length>=160) candidates.push({selector,text,paragraphCount:ps.length});
      }
    }
    if (!candidates.length) return {ok:false,error:'Contenu du chapitre introuvable : page non validée',title:pageTitle};
    candidates.sort((a,b)=>b.text.length-a.text.length);
    const best = candidates[0];
    // Refuse extremely long site indexes and accidentally captured navigation-only pages.
    if (best.text.length > 2_000_000) return {ok:false,error:'Contenu trop volumineux, page probablement incorrecte'};
    if (/access denied|verify you are human|captcha/i.test(best.text.slice(0,350))) return {ok:false,error:'Texte de vérification détecté'};
    const title = document.querySelector('h1')?.textContent?.trim() || pageTitle || 'Chapitre';
    return {ok:true,title:title.slice(0,500),text:best.text,chars:best.text.length,selector:best.selector,paragraphCount:best.paragraphCount};
  };
})();
