"""Offline-first QA: 236 synthetic chapters, errors, snapshots, Unicode and recovery."""
import hashlib
import json
import subprocess
import sys
import urllib.error
import zipfile
from pathlib import Path
from unittest.mock import patch

import pytest
import bookharvester as b


def story(n, text=None):
    text = text or f'In chapter {n}, the hero meets a wizard and learns the next lesson. ' * 3
    return f'<html><h1>Chapter {n}</h1><article><p>{text}</p></article></html>'.encode()


def test_simulated_236_chapter_complete_and_resume(tmp_path):
    calls=[]
    def offline(url, timeout=20):
        n=int(url.split('chapter-')[1].split('/')[0]); calls.append(n)
        return story(n), 'text/html; charset=utf-8'
    with patch.object(b, 'fetch', side_effect=offline):
        first=b.retrieve('Synthetic 236',tmp_path,'https://example.org/novel/', 'novel',count=236,delay=0,event=lambda x:None)
        second=b.retrieve('Synthetic 236',tmp_path,'https://example.org/novel/', 'novel',count=236,delay=0,event=lambda x:None)
    assert first['ok']==236 and first['remaining']==0
    assert second['skipped']==236 and len(calls)==236
    inv=b.inventory(b.Catalog(tmp_path/'library.sqlite3'),'Synthetic 236')
    assert inv['complete'] and inv['expected']==236
    book=b.export_epub('Synthetic 236',tmp_path,tmp_path/'book.epub')
    with zipfile.ZipFile(book) as epub:
        chapters=[name for name in epub.namelist() if name.startswith('OEBPS/c') and name.endswith('.xhtml')]
        assert len(chapters)==236
        assert 'Chapter 236' in epub.read('OEBPS/c00236.xhtml').decode()


def test_power_loss_midway_recovery_without_redownload(tmp_path):
    calls=[]
    def offline(url,timeout=20):
        n=int(url.split('chapter-')[1].split('/')[0]);calls.append(n)
        if n==4 and calls.count(4)==1:
            raise b.RetrievalError('power/network lost')
        return story(n),'text/html'
    with patch.object(b,'fetch',side_effect=offline):
        first=b.retrieve('Power Recovery',tmp_path,'https://example.org/novel/','novel',count=6,delay=0,event=lambda x:None)
        assert first['remaining']==1
        with pytest.raises(ValueError,match='incomplet'):
            b.export_pdf('Power Recovery',tmp_path,tmp_path/'no.pdf')
        second=b.retrieve('Power Recovery',tmp_path,'https://example.org/novel/','novel',count=6,delay=0,event=lambda x:None)
    assert second['ok']==1 and second['skipped']==5
    assert calls==[1,2,3,4,5,6,4]
    assert b.inventory(b.Catalog(tmp_path/'library.sqlite3'),'Power Recovery')['complete']


def test_duplicate_chapters_do_not_get_complete_badge(tmp_path):
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan('Repeat',[(1,'https://example.org/a'),(2,'https://example.org/b')],'novel',expected_end=2)
    body='The same chapter repeated verbatim by server.'*4
    d=hashlib.sha256(body.encode()).hexdigest()
    cat.complete('Repeat',1,'First',body,'novel',d)
    cat.complete('Repeat',2,'Second',body,'novel',d)
    inv=b.inventory(cat,'Repeat')
    assert not inv['complete'] and inv['duplicates']==[2]


def test_corrupted_text_hash_prevents_complete_export(tmp_path):
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan('Damaged',[(1,'https://example.org/a')],'novel',expected_end=1)
    cat.complete('Damaged',1,'One','wizard wizard '*10,'novel','badhash')
    assert b.inventory(cat,'Damaged')['integrity_errors']==[1]
    with pytest.raises(ValueError): b.export_epub('Damaged',tmp_path,tmp_path/'bad.epub')


def test_public_source_url_restrictions():
    urls=['http://192.168.1.1/','http://[::1]/','http://169.254.169.254/latest/meta-data','http://localhost/','ftp://example.com','file:///etc/hosts']
    for url in urls:
        with pytest.raises(ValueError): b.check_url(url)
    assert b.check_url('https://example.org/book/')


def test_canonical_preserves_page_query_parameter():
    assert b.canonical('https://example.org/read?chapter=5')=='https://example.org/read/?chapter=5'


def test_http_403_and_429_no_attempt_to_bypass():
    for code in (403,429):
        error=urllib.error.HTTPError('https://example.org/',code,'not allowed',{},None)
        with patch.object(b.urllib.request,'urlopen',side_effect=error) as call:
            with pytest.raises(b.AccessBlocked,match=str(code)): b.fetch('https://example.org/')
        assert call.call_count==1


def test_html_no_content_not_validated():
    with pytest.raises(b.RetrievalError): b.extract_text('<html><div class="advertisement">Only an advertisement</div></html>')


def test_stop_event_prevents_calls(tmp_path):
    from threading import Event
    stop=Event();stop.set()
    with patch.object(b,'fetch') as f:
        r=b.retrieve('Stopped',tmp_path,'https://example.org/story/','novel',count=4,delay=0,event=lambda m:None,stop=stop)
    assert r['remaining']==4 and f.call_count==0


def test_mhtml_offline_import(tmp_path):
    import email.mime.multipart
    import email.mime.text
    source=tmp_path/'saved';source.mkdir()
    msg=email.mime.multipart.MIMEMultipart('related')
    msg.attach(email.mime.text.MIMEText(story(1).decode(),'html','utf-8'))
    (source/'chapter-001.mhtml').write_bytes(msg.as_bytes())
    result=b.import_html('Mhtml Book',source,tmp_path/'storage')
    assert result['imported']==[1] and not result['rejected']


def test_unicode_chapter_round_trip(tmp_path):
    body='Русский и français et 한국어 plus une histoire de magie. '*5
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan('Unicode',[(1,'https://example.org/a')],'novel',expected_end=1)
    cat.complete('Unicode',1,'Глава 1',body,'novel',hashlib.sha256(body.encode()).hexdigest())
    out=b.export_epub('Unicode',tmp_path,tmp_path/'unicode.epub')
    with zipfile.ZipFile(out) as z:
        assert body.strip() in z.read('OEBPS/c00001.xhtml').decode()


def test_cli_selftest_and_expected_count(tmp_path):
    script=Path(b.__file__)
    p=subprocess.run([sys.executable,str(script),'--self-test'],capture_output=True,text=True,check=True)
    assert json.loads(p.stdout)['ok']
    env={**__import__('os').environ,'BOOKHARVESTER_HOME':str(tmp_path)}
    p=subprocess.run([sys.executable,str(script),'--book','Novel','--expect','236','--check'],capture_output=True,text=True,env=env,check=True)
    status=json.loads(p.stdout)
    assert status['expected']==236 and status['complete'] is False and len(status['holes'])==236


def test_pdf_text_and_page_count(tmp_path):
    import pypdf
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan('PDF QA',[(n,f'https://example.org/c/{n}') for n in range(1,5)],'novel',expected_end=4)
    for n in range(1,5):
        content=f'This is the complete synthetic chapter {n} repeated. '*6
        cat.complete('PDF QA',n,f'Chapter {n}',content,'novel',hashlib.sha256(content.encode()).hexdigest())
    path=b.export_pdf('PDF QA',tmp_path,tmp_path/'test.pdf')
    reader=pypdf.PdfReader(str(path))
    result='\n'.join(page.extract_text() or '' for page in reader.pages)
    assert len(reader.pages)>=5
    assert 'Chapter 1' in result and 'Chapter 4' in result
    assert 'COMPLETE' not in result or 'COMPLET' in result


def test_manga_corruption_rejected_at_export(tmp_path):
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan('Comic',[(1,'https://example.org/manga/1')],'manga',expected_end=1)
    path=tmp_path/'page.png';path.write_bytes(b'pretend valid test bytes')
    cat.save_image('Comic',1,1,path,hashlib.sha256(path.read_bytes()).hexdigest())
    cat.complete('Comic',1,'chapter 1','1','manga','ok')
    path.write_bytes(b'corrupt bytes')
    with pytest.raises(ValueError,match='corrompue'):
        b.export_cbz('Comic',tmp_path,tmp_path/'bad.cbz')
