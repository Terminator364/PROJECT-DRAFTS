import hashlib
import json
import sqlite3
import zipfile
from pathlib import Path
from unittest.mock import patch

import pytest
import bookharvester as b

HTML = b'''<html><head><title>Novel</title></head><body><div class="advertisement">buy more</div>
<h1>Chapter 1</h1><div class="reading-content"><p>Once upon a time, there was a wizard who studied magic.</p>
<p>His journey continued through the city, and many people learned his name.</p><script>alert('ads')</script></div></body></html>'''


def test_extract_text():
    title, content = b.extract_text(HTML)
    assert title == 'Chapter 1'
    assert 'wizard' in content and 'journey' in content
    assert 'alert' not in content
    assert 'buy more' not in content


def test_failed_blocked_page():
    with pytest.raises(b.AccessBlocked):
        b.extract_text('<html><title>Just a moment...</title><div class="reading-content">captcha</div></html>')


def test_urls_pattern_and_discovery():
    urls=b.urls_by_pattern('https://example.org/novel/test/',3)
    assert urls[0][1]=='https://example.org/novel/test/chapter-1/'
    assert urls[-1][1]=='https://example.org/novel/test/chapter-3/'
    listing=b'<a href="/novel/test/chapter-3/">Chapter 3</a><a href="/novel/test/chapter-2/">Chapter 2</a>'
    assert [n for n,_ in b.discover(listing,'https://example.org/novel/test/')]==[2,3]


def test_network_retrieval_resume_epub_pdf(tmp_path):
    calls=[]
    def fake_fetch(url,timeout=20):
        calls.append(url)
        return HTML.replace(b'Chapter 1',f'Chapter {len(calls)}'.encode()).replace(b'Once upon a time',f'In chapter {len(calls)} the tale began'.encode()), 'text/html'
    with patch.object(b,'fetch',side_effect=fake_fetch):
        result=b.retrieve('Wizard Story',tmp_path,'https://example.org/novel/test/', 'novel',count=3,delay=0,event=lambda m:None)
        assert result['ok']==3
        result2=b.retrieve('Wizard Story',tmp_path,'https://example.org/novel/test/', 'novel',count=3,delay=0,event=lambda m:None)
        assert result2['skipped']==3
    assert len(calls)==3
    assert b.inventory(b.Catalog(tmp_path/'library.sqlite3'),'Wizard Story')['complete']
    epub=b.export_epub('Wizard Story',tmp_path,tmp_path/'test.epub')
    pdf=b.export_pdf('Wizard Story',tmp_path,tmp_path/'test.pdf')
    assert pdf.read_bytes()[:4]==b'%PDF'
    with zipfile.ZipFile(epub) as f:
        assert f.read('mimetype') == b'application/epub+zip'
        assert 'wizard' in f.read('OEBPS/c00001.xhtml').decode()


def test_partial_rejected(tmp_path):
    catalog=b.Catalog(tmp_path/'library.sqlite3')
    catalog.plan('Story',[(1,'https://example.org/ch1'),(2,'https://example.org/ch2')],'novel')
    content='x'*110
    catalog.complete('Story',1,'One',content,'novel',hashlib.sha256(content.encode()).hexdigest())
    with pytest.raises(ValueError,match='incomplet'):
        b.export_epub('Story',tmp_path,tmp_path/'out.epub')
    b.export_epub('Story',tmp_path,tmp_path/'out.epub',allow_partial=True)
    with zipfile.ZipFile(tmp_path/'out.epub') as archive:
        assert 'INCOMPLET' in archive.read('OEBPS/content.opf').decode()


def test_block_is_stopped_not_retried(tmp_path):
    with patch.object(b,'fetch',side_effect=b.AccessBlocked('HTTP 403')) as fake_fetch:
        report=b.retrieve('Story',tmp_path,'https://example.com/story/', 'novel',count=4,delay=0,event=lambda x:None)
    assert fake_fetch.call_count==1
    assert report['blocked'] and report['remaining']==4


def test_saved_html_fallback(tmp_path):
    source=tmp_path/'html'
    source.mkdir()
    (source/'chapter-001.html').write_bytes(HTML)
    report=b.import_html('Story',source,tmp_path/'book')
    assert report['imported']==[1]
    assert b.inventory(b.Catalog(tmp_path/'book'/'library.sqlite3'),'Story')['ok']==1


def test_image_extraction_and_cbz(tmp_path):
    page='<article><img src="/pages/1.png"/><img data-src="https://cdn.example.org/p2.jpg"/></article>'
    assert b.extract_images(page,'https://example.org/story/ch1')==['https://example.org/pages/1.png','https://cdn.example.org/p2.jpg']
    book='Manga'
    cat=b.Catalog(tmp_path/'library.sqlite3')
    cat.plan(book,[(1,'https://example.org/ch1')],'manga',expected_end=1)
    path=tmp_path/'a.png'
    path.write_bytes(b'\x89PNGfake image bytes for test')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    cat.save_image(book,1,1,path,digest)
    cat.complete(book,1,'Chapter 1','1','manga',digest)
    out=b.export_cbz(book,tmp_path,tmp_path/'comic.cbz')
    with zipfile.ZipFile(out) as z:
        assert z.namelist()==['00001/0001.png']


def test_reject_private_urls():
    for url in ['file:///etc/passwd','http://localhost/admin','http://127.0.0.1/test','http://10.0.0.1/']:
        with pytest.raises(ValueError):
            b.check_url(url)
