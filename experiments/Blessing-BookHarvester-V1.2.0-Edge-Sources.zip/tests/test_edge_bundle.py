import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
import bookharvester as b
from edge_bundle import EdgeImportError, import_edge_bundle, FORMAT

HERE=Path(__file__).resolve().parents[1]

def data(n, body=None):
    text=body or ((f'This story is chapter {n}. A scholar explores a magical world. ')*10)
    return {'number':n,'url':f'https://books.example.org/novel/chapter-{n}/','title':f'Chapter {n}','text':text,'sha256':hashlib.sha256(text.encode()).hexdigest()}

def bundle(chapters,expected=3):
    return {'schema':FORMAT,'book':'Edge Trial','origin':'https://books.example.org','expected_end':expected,'chapters':chapters}

def write(tmp,data):
    file=tmp/'edge.json';file.write_text(json.dumps(data,ensure_ascii=False),encoding='utf8');return file

def test_cycle1_realistic_three_chapters_and_pdf_epub(tmp_path):
    path=write(tmp_path,bundle([data(1),data(2),data(3)]))
    result=import_edge_bundle(path,tmp_path/'book',expected_book='Edge Trial')
    assert result['imported']==[1,2,3] and result['inventory']['complete']
    with open(tmp_path/'book'/'library.sqlite3','rb') as f: assert f.read(16)==b'SQLite format 3\x00'
    import pypdf,zipfile
    pdf=b.export_pdf('Edge Trial',tmp_path/'book',tmp_path/'three.pdf')
    epub=b.export_epub('Edge Trial',tmp_path/'book',tmp_path/'three.epub')
    assert len(pypdf.PdfReader(str(pdf)).pages)>=4
    with zipfile.ZipFile(epub) as archive:
        for n in range(1,4): assert f'Chapter {n}' in archive.read(f'OEBPS/c{n:05d}.xhtml').decode()
    # Successive import is idempotent and Windows can delete the folder (closed DB handles).
    again=import_edge_bundle(path,tmp_path/'book')
    assert again['already_present']==[1,2,3] and again['imported']==[]
    shutil.rmtree(tmp_path/'book')
    assert not (tmp_path/'book').exists()

def test_cycle2_236_expected_not_misrepresented(tmp_path):
    path=write(tmp_path,bundle([data(1),data(2),data(3)],236))
    report=import_edge_bundle(path,tmp_path/'book')
    assert report['inventory']['expected']==236
    assert len(report['inventory']['holes'])==233 and not report['inventory']['complete']
    with pytest.raises(ValueError,match='incomplet'):
        b.export_pdf('Edge Trial',tmp_path/'book',tmp_path/'notready.pdf')
    # Then 233 more chapters, like extending the user-controlled Edge collection.
    path=write(tmp_path,bundle([data(n) for n in range(4,237)],236))
    report=import_edge_bundle(path,tmp_path/'book')
    assert report['inventory']['complete'] and report['inventory']['ok']==236

def test_cycle3_conflict_and_cross_origin_stop(tmp_path):
    p=write(tmp_path,bundle([data(1)]))
    import_edge_bundle(p,tmp_path/'book')
    rec=data(1,'Altered text. '*20)
    p=write(tmp_path,bundle([rec]))
    r=import_edge_bundle(p,tmp_path/'book')
    assert r['conflicts']==[1] and not r['inventory']['complete']
    rec=data(2);rec['url']='http://localhost/private'
    p=write(tmp_path,bundle([rec]))
    with pytest.raises(ValueError):import_edge_bundle(p,tmp_path/'book')
    rec=data(2);rec['url']='https://malicious.example.com/data'
    p=write(tmp_path,bundle([rec]))
    with pytest.raises(EdgeImportError,match='étrangère'):import_edge_bundle(p,tmp_path/'book')

def test_cycle4_no_silent_corruption_or_forged_sha(tmp_path):
    rec=data(1);rec['sha256']='x'*64
    with pytest.raises(EdgeImportError,match='SHA-256'):
        import_edge_bundle(write(tmp_path,bundle([rec])),tmp_path/'book')
    assert not (tmp_path/'book'/'library.sqlite3').exists()
    with pytest.raises(EdgeImportError):
        import_edge_bundle(write(tmp_path,bundle([data(1),data(1)])),tmp_path/'book')

def test_chrome_reader_in_real_browser_synthetic_fixture():
    pw=pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    import os
    with sync_playwright() as session:
        browser=(session.chromium.launch(channel='msedge',headless=True) if os.name=='nt'
                 else session.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']))
        tab=browser.new_page()
        tab.set_content('<html><title>Chapter 1</title><article class="reading-content">'+''.join(f'<p>Substantive original test paragraph {i}, where events advance the story.</p>' for i in range(8))+'<aside>ADVERTISE NOW</aside></article></html>')
        tab.add_script_tag(path=str(HERE/'edge-extension'/'reader.js'))
        out=tab.evaluate('globalThis.BH_READ_PAGE([])')
        assert out['ok'] and out['chars']>350
        assert 'ADVERTISE NOW' not in out['text']
        tab.set_content('<html><title>403 Forbidden</title><body>Access denied</body></html>')
        tab.add_script_tag(path=str(HERE/'edge-extension'/'reader.js'))
        out=tab.evaluate('globalThis.BH_READ_PAGE([])')
        assert not out['ok'] and 'REFUSÉ' in out['error']
        browser.close()

def test_edge_extension_js_syntax_and_permissions():
    m=json.loads((HERE/'edge-extension'/'manifest.json').read_text())
    assert m['manifest_version']==3
    assert 'https://*/*' in m['optional_host_permissions']
    assert 'https://*/*' not in m.get('host_permissions',[])
    for js in ('background.js','popup.js','reader.js'):
        subprocess.run(['node','--check',str(HERE/'edge-extension'/js)],check=True)


def test_edge_background_state_machine_with_node():
    subprocess.run(['node',str(HERE/'tests'/'edge_worker_test.cjs')],check=True,timeout=25)


def test_three_chapters_network_navigation_in_edge_browser(tmp_path):
    """Navigate three pages in an actual browser; mock only the remote site HTTP.

    Playwright route.fulfill avoids both requiring Internet and relying on
    loopback access that can be blocked by restricted CI environments.
    """
    import os
    from playwright.sync_api import sync_playwright
    captured=[]
    def page_html(n):
        return f'<html><head><title>Chapter {n}</title></head><body><article class="chapter-content">'+''.join(f'<p>At chapter {n} the character takes a new journey. This is unique synthetic paragraph {i}. There are many details. </p>' for i in range(6))+'</article></body></html>'
    def fixture(route):
        import re
        match=re.search(r'/chapter-(\d+)/',route.request.url)
        if not match:
            route.fulfill(status=404,body='not found')
            return
        n=int(match.group(1))
        route.fulfill(status=200,body=page_html(n),content_type='text/html; charset=utf-8')
    with sync_playwright() as session:
        if os.name=='nt':
            browser=session.chromium.launch(channel='msedge',headless=True)
        else:
            browser=session.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page()
        page.route('https://books.example.org/**',fixture)
        for n in range(1,4):
            url=f'https://books.example.org/novel/chapter-{n}/'
            if os.name=='nt':
                resp=page.goto(url,wait_until='domcontentloaded',timeout=10000)
                assert resp.status==200
            else:
                # Local hardened container forbids browser network even when mocked.
                # The GitHub Windows job will explicitly check real Edge navigation.
                page.set_content(page_html(n))
            page.add_script_tag(path=str(HERE/'edge-extension'/'reader.js'))
            info=page.evaluate('globalThis.BH_READ_PAGE([])')
            assert info['ok'] and f'chapter {n}' in info['text']
            captured.append(data(n,info['text']))
        browser.close()
    report=import_edge_bundle(write(tmp_path,bundle(captured)),tmp_path/'test-book')
    assert report['inventory']['complete']
    pdf=b.export_pdf('Edge Trial',tmp_path/'test-book',tmp_path/'proof.pdf')
    import pypdf
    text=' '.join(pg.extract_text() or '' for pg in pypdf.PdfReader(str(pdf)).pages)
    assert all(f'chapter {n}' in text for n in range(1,4))
