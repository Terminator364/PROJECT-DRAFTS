'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync(require('path').join(__dirname,'..','edge-extension','background.js'),'utf8');
async function session(blockedAt=0){
  const store={};let onMessage,onUpdated;let visited=[];const tab={id:12,url:'https://books.example.org/novel/'};
  const chrome={
    storage:{local:{async set(next){Object.assign(store,next);},async get(keys){const o={};for(const k of keys)o[k]=store[k];return o;}}},
    tabs:{onUpdated:{addListener(cb){onUpdated=cb;}},async get(id){assert.equal(id,tab.id);return tab;},async update(id,params){assert.equal(id,tab.id);tab.url=params.url;visited.push(tab.url);setTimeout(()=>onUpdated(id,{status:'complete'}),15);return tab;}},
    scripting:{async executeScript(args){if(args.files)return [{}];let n=parseInt(tab.url.match(/chapter-(\d+)/)?.[1]||0);if(n===blockedAt)return [{result:{ok:false,error:'Access denied'}}];let text=('Original fixture for chapter '+n+' and meaningful narrative progression. ').repeat(6);return [{result:{ok:true,title:'Chapter '+n,text,chars:text.length}}];}},
    runtime:{onMessage:{addListener(cb){onMessage=cb;}}}
  };
  vm.runInNewContext(code,{chrome,URL,Date,Set,Math,Array,String,Number,Error,Promise,console,setTimeout:(cb,ms)=>setTimeout(cb,Math.min(ms,1))});
  const send=(type,rest={})=>new Promise((resolve,reject)=>{onMessage({type,...rest},{},resolve);setTimeout(()=>reject(Error('No response '+type)),2000);});
  const wait=async(state,count)=>{for(let k=0;k<140;k++){await new Promise(r=>setTimeout(r,12));if(store.bh_job_v1?.state===state && store.bh_chapters_v1?.length===count)return;}throw Error('Timed out, state='+JSON.stringify(store.bh_job_v1));};
  const params={book:'Fixture Novel',pattern:'https://books.example.org/novel/chapter-{n}/',first:1,last:3,expected:236,tabId:12,delayMs:1500};
  assert((await send('START',{params})).ok);await wait(blockedAt?'paused':'done',blockedAt?blockedAt-1:3);
  if(blockedAt){assert(visited.length===blockedAt);assert.equal(store.bh_chapters_v1.length,blockedAt-1);return;}
  assert(store.bh_chapters_v1.map(x=>x.number).join(',')==='1,2,3');
  assert((await send('START',{params:{...params,last:5}})).ok);await wait('done',5);
  assert.equal(store.bh_chapters_v1.length,5);
  assert.equal(store.bh_chapters_v1.filter(c=>c.number===1).length,1);
  assert(visited.length===5);
}
(async()=>{await session();await session(2);console.log('OK edge background worker: 3+2 continuation, stop on blocked chapter');})().catch(e=>{console.error(e);process.exit(1)});
