# Blessing BookHarvester V1.2 — Edge + HTTP

**Statut : candidat QA, ne pas confondre tests synthétiques et accès réel à Ranovel.**

Ce logiciel Windows archivera uniquement les contenus que vous avez le droit d'enregistrer, soit par HTTP pour les sites compatibles, soit via une extension Microsoft Edge lisant le DOM des chapitres déjà accessibles dans le navigateur. Il n'évite ni CAPTCHA, ni paiement, ni restrictions d'accès. Aucun texte de livres tiers n'est inclus dans le logiciel ou envoyé à GitHub.

## Première installation (sans Python)

1. Télécharger le ZIP Windows depuis l'artefact CI GitHub, puis **extraire tout le ZIP**.
2. Lancer `Install-Portable.bat`. Autodiagnostic Windows intégré, installation dans `%LOCALAPPDATA%\BlessingBookHarvester\app-v1.2.0` et raccourci de bureau.
3. Pour la récupération avec **Microsoft Edge**, une seule activation manuelle est nécessaire : `edge://extensions` > `Mode développeur` > `Charger l'extension décompressée` > sélectionner `%LOCALAPPDATA%\BlessingBookHarvester\Edge-Extension`.
4. Ouvrir normalement le site du roman dans Edge et s'assurer qu'un chapitre est consultable. Cliquer l'extension BookHarvester et confirmer la permission d'accès au domaine.
5. Pour le test d'un nouveau site, collecter d'abord **chapitres 1 à 3** ; le titre, le total attendu (par ex. 236) et le patron de chapitre doivent être exacts. L'extension change de page avec un délai, sauvegarde le contenu et s'arrête sur refus d'accès.
6. Dans l'extension cliquer `Exporter les chapitres en JSON`, puis dans l'application Windows `Importer Edge JSON`. L'application vérifiera la progression, la cohérence de l'origine, les doublons et le SHA-256. Utiliser `PDF aperçu partiel` si seuls les 3 premiers chapitres ont été récupérés.
7. Pour continuer, revenir dans Edge, mettre le dernier chapitre sur 236 et cliquer `Démarrer` : les 3 premiers restent en mémoire. Reprise après interruption disponible avec `Reprendre`.

## Intégrité, confidentialité et limites

- SQLite conserve les chapitres validés localement. L'accès HTTP 403, 429 ou une page de contrôle provoque un **arrêt explicite** sans contournement.
- Les chapitres téléchargés/importés restent dans `%USERPROFILE%\Documents\Blessing BookHarvester`.
- L'export PDF ou EPUB **complet** est refusé lorsque le total attendu n'est pas atteint, lorsqu'un chapitre a échoué ou lorsqu'un hash est invalide. L'aperçu partiel est identifié comme tel.
- Le pont Edge ne collecte pour le moment que les romans texte ; les mangas sont gérés par le récupérateur d'images HTTP quand les sources autorisent l'accès et l'export CBZ.
- L'extension Edge ne se met pas en place sans votre approbation : le navigateur exige un chargement manuel de l'extension décompressée.
- **Ranovel n'est pas certifié** : deux tests précédents sur GitHub (HTTP et navigateur Chrome) ont retourné HTTP 403 pour le chapitre 1. Un vrai essai depuis le Edge du PC de l'utilisateur reste nécessaire si ce site lui autorise la consultation.
- Application non signée : Windows SmartScreen peut afficher un avertissement ; vérifier la provenance GitHub et le SHA-256 avant d'exécuter.

## Vérification automatisée

Tests synthétiques : navigateur Chromium (Linux), Microsoft Edge sur `windows-latest` (via Playwright), navigation navigateur interceptée vers 3 chapitres de test, DOM → extension logique → fichier JSON → SQLite → EPUB/PDF, 236 chapitres artificiels, corruption, conflits, liens étrangers, arrêt 403 et reprise 3+2 chapitres. Exécutable Windows PyInstaller `--onedir`, autotest de l'interface Tkinter, véritable script d'installation et vérification du raccourci sur `windows-latest`.

**Critères de validation de Ranovel** : au moins 3 chapitres réels accessibles et distincts dans Edge sur une connexion autorisée, leurs longueurs et SHA vérifiés, export PDF/EPUB vérifié, puis extension sur l'ensemble du roman avec inventaire final complet. Un runner GitHub recevant HTTP 403 ne peut certifier cette étape.
