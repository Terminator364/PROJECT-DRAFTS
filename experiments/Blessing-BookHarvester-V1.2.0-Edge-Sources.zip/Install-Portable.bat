@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Portable.ps1"
if errorlevel 1 (
  echo Installation echouee. Conserver cette fenetre pour le diagnostic.
  pause
  exit /b 1
)
echo Installation OK. Utiliser le raccourci du bureau.
pause
