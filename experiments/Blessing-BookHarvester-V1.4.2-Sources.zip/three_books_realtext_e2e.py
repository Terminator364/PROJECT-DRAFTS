"""A-to-Z integration against 3 authentic public-domain Gutenberg source texts.

Downloads ONE official plain-text file per book. Extracts the 77 actual chapters,
then tests the BookHarvester web-page/HTML/SQLite/export pipeline against local
in-memory pages derived from those sources.  The 77 page fetches are controlled
integration simulations, NOT 77 independent HTTP requests to a third-party host.
No copyrighted narrative is included in the GitHub repo or uploaded as CI artifacts.
"""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import html
import json
import random
import re
import sys
import tempfile
import urllib.request
import urllib.error
import zipfile
from contextlib import contextmanager
from pathlib import Path

import bookharvester as bh
from pypdf import PdfReader

BOOKS = [
    {"id": 11, "title": "Alice's Adventures in Wonderland", "count": 12, "kind": "numbered"},
    {"id": 54, "title": "The Marvelous Land of Oz", "count": 24, "kind": "oz"},
    {"id": 51, "title": "Anne of the Island", "count": 41, "kind": "numbered"},
]
BASE = "https://fiction-fixture.example.org/"
GUTENBERG = "https://www.gutenberg.org/cache/epub/{id}/pg{id}.txt"
# Project Gutenberg texts mirrored in public Git repositories. Offline QA uses
# real books and recorded source provenance, not generated novel content.
PUBLIC_MIRRORS = {
    11: ('https://raw.githubusercontent.com/GITenberg/Alice-s-Adventures-in-Wonderland_11/master/11-0.txt', 12),
    54: ('https://raw.githubusercontent.com/GITenberg/The-Marvelous-Land-of-Oz_54/master/54.txt', 24),
    51: ('https://raw.githubusercontent.com/GITenberg/Anne-of-the-Island_51/master/51-0.txt', 41),
}

END_MARKER = re.compile(r"(?im)^\*\*\* END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK.*$")
ROMANS = "IVXLCDM"


def roman(number: int) -> str:
    pieces=[]
    for value, letter in ((1000,'M'),(900,'CM'),(500,'D'),(400,'CD'),(100,'C'),(90,'XC'),(50,'L'),(40,'XL'),(10,'X'),(9,'IX'),(5,'V'),(4,'IV'),(1,'I')):
        while number>=value:
            pieces.append(letter);number-=value
    return ''.join(pieces)


def trim_gutenberg(text: str) -> str:
    # Normalize CRLF/CR before matching anchored headings on Windows runner.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    begin = re.search(r"(?im)^\*\*\* START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*$", text)
    if not begin: raise AssertionError("Missing Gutenberg START marker")
    text = text[begin.end():]
    end = END_MARKER.search(text)
    if not end: raise AssertionError("Missing Gutenberg END marker")
    return text[:end.start()].strip()


def parse_numbered(text: str, expected: int):
    # Gutenberg Alice has standalone 'CHAPTER I.' headers; Anne has 'Chapter I'.
    hits = list(re.finditer(r"(?im)^[ \t]*CHAPTER[ \t]+([IVXLCDM]+)\.?(?:[ \t]+[^\r\n]*)?$", text))
    ranges=[(m.start(),m.end(),m.group(1).upper()) for m in hits]
    pattern=[roman(n) for n in range(1,expected+1)]
    # GITenberg Anne #51 has a printing/OCR defect: its last heading is a
    # standalone "XLI", without "Chapter". The official 41-chapter text is
    # preferred, but accept only the very specific last missing numeral.
    if expected==41 and [x[2] for x in ranges]==pattern[:-1]:
        extra=list(re.finditer(r"(?im)^[ \t]*XLI[ \t]*$",text[ranges[-1][1]:]))
        if len(extra)==1:
            m=extra[0];offset=ranges[-1][1]
            ranges.append((offset+m.start(),offset+m.end(),'XLI'))
    found=[x[2] for x in ranges]
    if found != pattern:
        raise AssertionError(f"Chapter headings count/order not correct: expected {expected}, got {len(found)}; {found[:12]}")
    return [(f"Chapter {label}",text[end:ranges[i+1][0] if i+1<len(ranges) else len(text)].strip())
            for i,(start,end,label) in enumerate(ranges)]


def parse_oz(text: str):
    toc_match=re.search(r"(?im)^\s*LIST OF CHAPTERS\s*$",text)
    if not toc_match: raise AssertionError("Oz contents not found")
    tail=text[toc_match.end():]
    # The TOC is followed by two or more blank lines. Use the first 24
    # non-empty lines as expected headings; actual text has slight variations.
    preview=tail.splitlines()[:150]
    # Older Gutenberg paperback edition: chapters followed by printed PAGE
    # numbers in the TOC, and even a standalone PAGE line. Exclude page data.
    printed=[]
    for line in preview:
        m=re.match(r"^\s*(.*?)\s{2,}\d{1,3}\s*$",line)
        if m and len(m.group(1).strip())>6:
            printed.append(m.group(1).strip())
    toc_lines=printed[:24] if len(printed)>=24 else [line.strip() for line in tail.splitlines() if line.strip()][:24]
    if len(toc_lines)!=24:raise AssertionError("Oz contents count mismatch")
    normalized=lambda s:re.sub(r"[^a-z0-9]","",s.lower())
    # Find the last exact title in TOC, not a mention of a chapter in story.
    last=toc_lines[-1]
    pos=tail.find(last)
    if pos<0:raise AssertionError("Last TOC title missing")
    story=tail[pos+len(last):]
    lines=story.splitlines(keepends=True)
    offsets=[];x=0
    for line in lines:offsets.append(x);x+=len(line)
    chunks=[];found=[];cur=0
    for title in toc_lines:
        norm=normalized(title)
        options=[]
        for i in range(cur,len(lines)):
            candidate=lines[i].strip()
            if not candidate or len(candidate)>100:continue
            score=difflib.SequenceMatcher(None,norm,normalized(candidate)).ratio()
            if score>=0.76:
                # Distinct headings have a blank line before and after.
                before=(i==0 or not lines[i-1].strip())
                after=(i==len(lines)-1 or not lines[i+1].strip())
                if before and after:options.append((score,i,candidate))
            if len(options)>0 and i>options[0][1]+100:break
        if not options:raise AssertionError(f"Oz section not found: {title}")
        options.sort(key=lambda item:(item[1],-item[0]))
        score,ix,actual=options[0]
        found.append((ix,actual))
        cur=ix+1
    if len(found)!=24 or [x[0] for x in found]!=sorted(x[0] for x in found):raise AssertionError("Oz headings wrong order")
    for i,(index,name) in enumerate(found):
        start=offsets[index]+len(lines[index]);end=offsets[found[i+1][0]] if i+1<len(found) else len(story)
        chunks.append((name,story[start:end].strip()))
    return chunks


def chapters(source: str, entry: dict):
    trimmed=trim_gutenberg(source)
    portions=parse_oz(trimmed) if entry['kind']=='oz' else parse_numbered(trimmed,entry['count'])
    if len(portions)!=entry['count']:raise AssertionError('Chapter count does not match expected')
    if any(len(body)<600 for name,body in portions):
        raise AssertionError('Chapter content too small; probable bad chapter split')
    if len({hashlib.sha256(body.encode()).digest() for name,body in portions})!=len(portions):
        raise AssertionError('Duplicate text in source sections')
    return portions


def download_source(entry):
    """Prefer current official Gutenberg; if temporarily unavailable use a
    public Gutenberg mirror. Never mislabel a mirror edition as the official
    edition (Anne: historical 40 vs current 41 chapters).
    """
    official=GUTENBERG.format(**entry)
    mirror, mirror_count = PUBLIC_MIRRORS[entry['id']]
    errors=[]
    for label, url, edition_count in [('GUTENBERG_LIVE',official,entry['count']),
                                      ('GITENBERG_PUBLIC_MIRROR',mirror,mirror_count)]:
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'BlessingBookHarvester/1.4 (public-domain QA)'})
            with urllib.request.urlopen(req, timeout=25) as response:
                if response.status!=200:raise AssertionError(f'HTTP {response.status}')
                raw=response.read(1_500_001)
            if len(raw)>1_500_000:raise AssertionError('Public text exceeds limit')
            source=raw.decode('utf-8-sig')
            if not (re.search(r'(?im)^\*\*\* START OF (?:THIS |THE )?PROJECT GUTENBERG EBOOK',source)
                    and re.search(r'(?im)^\*\*\* END OF (?:THIS |THE )?PROJECT GUTENBERG EBOOK',source)):
                raise AssertionError('Not a Gutenberg source text; markers missing')
            return source,url,hashlib.sha256(raw).hexdigest(),label,edition_count,errors
        except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,AssertionError,UnicodeError) as exc:
            errors.append(label+': '+type(exc).__name__+' '+str(exc)[:90])
            print('SOURCE FALLBACK:',errors[-1],file=sys.stderr)
            continue
    raise AssertionError('Both official and public-domain mirrored source failed: '+str(errors))


def html_page(title, body):
    lines=body.splitlines()
    markup=''.join('<p>'+html.escape(line)+'</p>' for line in lines if line.strip())
    return (f'<html><head><title>{html.escape(title)}</title></head><body><nav>Prev / Next</nav>'
            f'<article class="reading-content"><h1>{html.escape(title)}</h1>{markup}</article></body></html>').encode('utf-8')


def simulate_book(root,entry,parts):
    title=entry['title'];count=entry['count']
    rng=random.Random(20261012+entry['id'])
    sample=sorted(rng.sample(range(1,count+1),3))
    base=f"{BASE}{entry['id']}/"
    targets=[(i,base+f'chapter-{i}/') for i in range(1,count+1)]
    pages={url:html_page(*parts[i-1]) for i,url in targets}
    original_fetch=bh.fetch
    requested=[]
    gate={'fail':False,'chapter':next(i for i in range(1,count+1) if i not in sample)}
    def controlled_fetch(url,timeout=20):
        requested.append(url)
        if gate['fail'] and url==targets[gate['chapter']-1][1]:
            raise bh.AccessBlocked('Simulated HTTP 403: stop and checkpoint')
        if url not in pages:raise bh.RetrievalError('Local test missing URL')
        return pages[url],'text/html; charset=utf-8'
    bh.fetch=controlled_fetch
    book_dir=root/('book-'+str(entry['id']))
    book_dir.mkdir(exist_ok=True)
    try:
        cat=bh.Catalog(book_dir/'library.sqlite3');cat.plan(title,targets,'novel',count)
        for n in sample:
            t,b=bh.extract_text(pages[targets[n-1][1]],min_chars=600)
            cat.complete(title,n,t,b,'novel',hashlib.sha256(b.encode()).hexdigest())
        partial=bh.inventory(cat,title)
        if partial['ok']!=3 or partial['complete']:raise AssertionError('Partial catalog falsely complete')
        cat.close()
        try:bh.export_pdf(title,book_dir,book_dir/'must_fail.pdf')
        except ValueError:pass
        else:raise AssertionError('Incomplete PDF unexpectedly accepted')
        gate['fail']=True
        one=bh.retrieve(title,book_dir,base,'novel',targets=targets,delay=0,event=lambda m:None)
        if not one['blocked'] or one['failed']!=1:raise AssertionError('403 stop did not trigger')
        gate['fail']=False
        two=bh.retrieve(title,book_dir,base,'novel',targets=targets,delay=0,event=lambda m:None)
        if two['remaining']!=0 or two['failed']!=0:raise AssertionError('Resumption incomplete')
        cat=bh.Catalog(book_dir/'library.sqlite3')
        try:
            inv=bh.inventory(cat,title);rows=cat.chapters(title)
        finally:cat.close()
        if not inv['complete'] or inv['ok']!=count or len(rows)!=count or inv['duplicates']:
            raise AssertionError(f'Inventory failed: {inv}')
        if any(len(row[3])<600 for row in rows):raise AssertionError('Short chapter after extraction')
        epub=bh.export_epub(title,book_dir,book_dir/'validated.epub')
        pdf=bh.export_pdf(title,book_dir,book_dir/'validated.pdf')
        with zipfile.ZipFile(epub) as z:
            zipped=[x for x in z.namelist() if re.fullmatch(r'OEBPS/c\d{5}\.xhtml',x)]
            if len(zipped)!=count:raise AssertionError('EPUB chapter count mismatch')
        bookpdf=PdfReader(str(pdf));text='\n'.join(p.extract_text() or '' for p in bookpdf.pages)
        # ReportLab defaults may transliterate typographic apostrophes; verify titles and source tokens.
        if len(bookpdf.pages)<count or len(text)<2000:
            raise AssertionError('PDF has missing chapters or blank pages')
        return {"name":title,"source_real_text":True,"chapters":count,"sample":sample,
                "first_pass_403_stopped":True,"resumed_ok":two['ok'],"skipped_on_resume":two['skipped'],
                "complete":True,"pdf_pages":len(bookpdf.pages),"epub_chapters":len(zipped),
                "source_chars":sum(len(b) for _,b in parts),"local_page_requests":len(requested),
                "exports_bytes":{"pdf":pdf.stat().st_size,"epub":epub.stat().st_size}}
    finally:bh.fetch=original_fetch


def run(root):
    root.mkdir(parents=True,exist_ok=True)
    report={'utc':dt.datetime.now(dt.timezone.utc).isoformat(), 'mode':'3 live bulk Gutenberg source downloads + controlled web-pages E2E simulations',
            'full_remote_per_chapter_site_test':False,'ranovel_certified':False,'books':[],'all_pass':False}
    path=root/'qa-report.json'
    for entry in BOOKS:
        item={'name':entry['title'],'expected':entry['count'],'status':'PENDING'}
        report['books'].append(item)
        path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
        try:
            source,url,digest,source_type,edition_count,errors=download_source(entry)
            edition={**entry,'count':edition_count}
            item['expected_original_edition_chapters']=entry['count']
            item['expected']=edition_count
            item['actual_source_edition_chapters']=edition_count
            item['source_provenance']=source_type
            item['source_fallback_errors']=errors
            parts=chapters(source,edition)
            item.update(simulate_book(root,edition,parts))
            item.update({'url':url,'download_sha256_prefix':digest[:20],'status':'PASS'})
        except Exception as exc:
            item['status']='FAIL';item['error_type']=type(exc).__name__;item['error']=str(exc)[:250]
            break
        finally:
            path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    report['all_pass']=len(report['books'])==3 and all(x['status']=='PASS' for x in report['books'])
    path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['all_pass'] else 1

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('e2e-results'))
    args=p.parse_args();sys.exit(run(args.root))
