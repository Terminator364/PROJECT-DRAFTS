"""A-to-Z cycles for three randomized, nonconsecutive chapters."""
import hashlib
import json
import random
import zipfile
from unittest.mock import patch
from pathlib import Path

import pytest
import bookharvester as b


def chapter(n):
    body = (f"This is the content for chapter {n} with a unique paragraph, authorial narrative and dialog. " * 7)
    return f'<html><title>Book</title><h1>Episode {n}</h1><article><p>{body}</p></article></html>'.encode()


def test_random_three_valid_then_reuse_same_sample_with_no_new_network(tmp_path):
    numbers=sorted(random.Random(20261012).sample(range(1,237),3))
    seen=[]
    def fetch(url):
        n=int(url.split('chapter-')[1].split('/')[0]);seen.append(n)
        return chapter(n),'text/html'
    with patch.object(b,'fetch',side_effect=fetch):
        result=b.sample_three_chapters('Ranovel Simulation',tmp_path,'https://example.org/book/',236,seed=20261012,delay=0,event=lambda _:None)
        assert result['status']=='SAMPLE_PASS'
        assert result['sampled']==numbers
        assert result['validated']==3 and result['distinct_texts']==3
        assert result['full_book_complete'] is False
        assert result['blocked']==0
        assert seen==numbers
        again=b.sample_three_chapters('Ranovel Simulation',tmp_path,'https://example.org/book/',236,seed=20261012,delay=0,event=lambda _:None)
        assert again['validated']==3 and seen==numbers
        assert all(x['status']=='already_validated' for x in again['chapters'])
    with pytest.raises(ValueError,match='incomplet'):
        b.export_epub('Ranovel Simulation',tmp_path,tmp_path/'not_complete.epub')
    preview=b.export_pdf('Ranovel Simulation',tmp_path,tmp_path/'sample_preview.pdf',allow_partial=True)
    assert preview.stat().st_size > 800
    report=json.loads((tmp_path/'last_random_sample_report.json').read_text())
    assert report['status']=='SAMPLE_PASS'


def test_random_three_each_checked_and_reported_after_http403(tmp_path):
    called=[]
    def blocked(url):
        called.append(url)
        raise b.AccessBlocked('HTTP 403: restricted')
    with patch.object(b,'fetch',side_effect=blocked):
        result=b.sample_three_chapters('Restricted Source',tmp_path,'https://example.org/story/',236,seed=7,delay=0,event=lambda _:None)
    assert len(called)==3 and len(set(called))==3
    assert result['status']=='SAMPLE_FAIL' and result['blocked']==3
    assert result['validated']==0 and result['full_book_complete'] is False
    assert all(s['status']=='access_blocked' for s in result['chapters'])


def test_random_sample_resumes_one_failed_chapter_only(tmp_path):
    picked=sorted(random.Random(8).sample(range(1,237),3))
    failed_once=set()
    seen=[]
    def flaky(url):
        n=int(url.split('chapter-')[1].split('/')[0]);seen.append(n)
        if n==picked[1] and n not in failed_once:
            failed_once.add(n)
            raise b.RetrievalError('Offline connection lost')
        return chapter(n),'text/html'
    with patch.object(b,'fetch',side_effect=flaky):
        one=b.sample_three_chapters('Recovery',tmp_path,'https://example.org/story/',236,seed=8,delay=0,event=lambda _:None)
        two=b.sample_three_chapters('Recovery',tmp_path,'https://example.org/story/',236,seed=8,delay=0,event=lambda _:None)
    assert one['validated']==2 and one['status']=='SAMPLE_FAIL'
    assert two['validated']==3 and two['status']=='SAMPLE_PASS'
    assert seen==picked+[picked[1]]


def test_random_sample_then_full_236_only_missing_downloaded(tmp_path):
    seen=[]
    def fetch(url,timeout=20):
        n=int(url.split('chapter-')[1].split('/')[0]);seen.append(n)
        return chapter(n),'text/html; charset=utf-8'
    with patch.object(b,'fetch',side_effect=fetch):
        partial=b.sample_three_chapters('Whole Book',tmp_path,'https://example.org/novel/',236,seed=42,delay=0,event=lambda _:None)
        whole=b.retrieve('Whole Book',tmp_path,'https://example.org/novel/','novel',count=236,delay=0,event=lambda _:None)
    assert partial['status']=='SAMPLE_PASS'
    assert whole['skipped']==3 and whole['ok']==233
    assert len(seen)==236 and len(set(seen))==236
    cat=b.Catalog(tmp_path/'library.sqlite3')
    try: assert b.inventory(cat,'Whole Book')['complete']
    finally:cat.close()
    ebook=b.export_epub('Whole Book',tmp_path,tmp_path/'full.epub')
    with zipfile.ZipFile(ebook) as z:
        assert len([n for n in z.namelist() if n.startswith('OEBPS/c') and n.endswith('.xhtml')])==236


def test_bad_sampling_parameters_protected(tmp_path):
    for total in (0,1,2,20001):
        with pytest.raises(ValueError):b.sample_three_chapters('Bad',tmp_path,'https://example.com/',total)
    with pytest.raises(ValueError):b.sample_three_chapters('Bad',tmp_path,'http://localhost/',10)


def test_real_chromium_extension_random_worker_node():
    import shutil, subprocess
    if not shutil.which('node'):
        pytest.skip('Node.js unavailable')
    result=subprocess.run(['node',str(Path(__file__).with_name('edge_random_test.cjs'))],check=True,text=True,capture_output=True,timeout=25)
    assert 'PASS Edge/Chromium random' in result.stdout


def test_empty_failed_sample_must_not_produce_fake_pdf(tmp_path):
    with patch.object(b,'fetch',side_effect=b.AccessBlocked('HTTP 403')):
        report=b.sample_three_chapters('No Text',tmp_path,'https://example.org/book/',236,seed=17,delay=0,event=lambda _:None)
    assert report['validated']==0
    with pytest.raises(ValueError,match='Aucun chapitre valide'):
        b.export_pdf('No Text',tmp_path,tmp_path/'misleading.pdf',allow_partial=True)
    assert not (tmp_path/'misleading.pdf').exists()


def test_gutenberg_public_mirror_crlf_header_normalization():
    from three_books_realtext_e2e import trim_gutenberg, parse_numbered
    raw = (
        '*** START OF THIS PROJECT GUTENBERG EBOOK EXAMPLE ***\r\n'
        + 'CHAPTER I. A Start\r\n' + ('The first complete chapter is here.\r\n' * 28)
        + 'CHAPTER II. A Continuation\r\n' + ('The second complete chapter is here.\r\n' * 28)
        + '*** END OF THIS PROJECT GUTENBERG EBOOK EXAMPLE ***\r\n'
    )
    fragments=parse_numbered(trim_gutenberg(raw),2)
    assert len(fragments)==2
    assert all(len(body)>600 for _,body in fragments)


def test_gutenberg_anne_41_with_last_roman_heading_missing_chapter_word():
    from three_books_realtext_e2e import parse_numbered, roman
    parts=[]
    for n in range(1,42):
        heading=(f'Chapter {roman(n)}' if n<41 else 'XLI')
        parts.append(heading+'\n\n'+('This is original public domain narrative fixture. '*24))
    data='\n\n'.join(parts)
    actual=parse_numbered(data,41)
    assert len(actual)==41 and actual[-1][0]=='Chapter XLI'


def test_gutenberg_oz_printed_contents_not_confused_with_story():
    from three_books_realtext_e2e import parse_oz
    titles=[f'Extraordinary Adventure of Entity {chr(65+i)} in the Forest' for i in range(24)]
    table='\n'.join(f'{title:<61}{(i+1)*12}' for i,title in enumerate(titles))
    text='LIST OF CHAPTERS\n                                  PAGE\n'+table+'\n\n'
    for i,title in enumerate(titles,1):
        text+='\n\n'+str(i*12)+'      '+title+'\n\n'+('This fictional local QA narrative fixture is valid and lengthy. '*20)+'\n\n'
    got=parse_oz(text)
    assert len(got)==24 and all(len(body)>700 for _,body in got)
