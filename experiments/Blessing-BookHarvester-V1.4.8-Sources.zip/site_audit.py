"""Bounded preflight of public chapter URLs; never bypass or retry site restrictions.

Reports only status/headers/length/hash, never redistributes third-party text.
"""
from __future__ import annotations

import hashlib
import json
import random
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable


BLOCK_CODES = {401, 403, 407, 429, 451}
MAX_BODY = 5_000_000


def diagnose_http(url: str, timeout: int = 16, opener=None) -> dict:
    """Get one response; don't retry a protection, record server hints only."""
    from bookharvester import check_url, USER_AGENT
    check_url(url)
    req = urllib.request.Request(url, headers={
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml',
    })
    open_fn = opener or urllib.request.urlopen
    try:
        try:
            resp = open_fn(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            resp = exc
        with resp:
            status = int(resp.status if hasattr(resp, 'status') else resp.code)
            headers = resp.headers
            server = str(headers.get('Server', '')).split(' ', 1)[0].lower()
            mitigated = str(headers.get('cf-mitigated', '')).lower()
            cloudflare = ('cloudflare' in server or bool(headers.get('CF-Ray')))
            result = {'url': url, 'http_status': status, 'server': server or 'unknown',
                      'cloudflare_header': cloudflare, 'bytes_read': 0,
                      'status': 'not_validated'}
            if status in BLOCK_CODES:
                result['status'] = ('cloudflare_access_denied' if cloudflare and status == 403 else 'access_denied')
                result['mitigation'] = mitigated or None
                result['next_gate'] = 'verify_site_access_and_authorized_use'
                result['human_validation_guaranteed'] = False
                return result
            if status == 404:
                result['status'] = 'not_found'
                return result
            if not (200 <= status < 300):
                result['status'] = 'http_unexpected'
                return result
            target = resp.geturl() if hasattr(resp, 'geturl') else url
            check_url(target)
            if urllib.parse.urlsplit(target).hostname != urllib.parse.urlsplit(url).hostname:
                result['status'] = 'cross_origin_redirect'
                return result
            content_type = str(headers.get('Content-Type', '')).lower()
            if 'html' not in content_type:
                result['status'] = 'non_html'
                return result
            body = resp.read(MAX_BODY + 1)
            if len(body) > MAX_BODY:
                result['status'] = 'oversized_response'
                return result
            result['bytes_read'] = len(body)
            from bookharvester import extract_text, AccessBlocked, RetrievalError
            try:
                title, text = extract_text(body, min_chars=160)
                from chapter_identity import check_identity
                from chapter_identity import looks_like_index
                check = check_identity(title, url=url)
                result['status'] = ('index_page' if looks_like_index(body) else
                                    'valid_chapter_candidate' if check['status'] == 'verified'
                                    else check['status'])
                result['identity'] = check
                result['title_length'] = len(title)
                result['text_length'] = len(text)
                # The content digest is diagnostic; never publish the book text.
                result['sha256'] = hashlib.sha256(text.encode('utf-8')).hexdigest()
            except AccessBlocked:
                result['status'] = 'challenge_in_200_page'
            except RetrievalError:
                result['status'] = 'html_extraction_failed'
            return result
    except (OSError, TimeoutError) as exc:
        return {'url': url, 'status': 'network_error', 'error_type': type(exc).__name__}


def audit_three(base: str, total: int, *, seed: int, delay: float = 1.5,
                probe: Callable[[str], dict] = diagnose_http, pattern: str = 'chapter-{n}/') -> dict:
    from bookharvester import check_url, canonical
    if not 3 <= total <= 20_000 or '{n}' not in pattern:
        raise ValueError('invalid chapter count or URL pattern')
    if not 0 <= delay <= 120:
        raise ValueError('invalid delay')
    check_url(base)
    origin = urllib.parse.urlsplit(canonical(base)).netloc.lower()
    selection = sorted(random.Random(seed).sample(range(1, total+1), 3))
    entries = []
    for idx, n in enumerate(selection):
        url = urllib.parse.urljoin(canonical(base), pattern.format(n=n))
        if urllib.parse.urlsplit(check_url(url)).netloc.lower() != origin:
            raise ValueError('chapter redirects outside selected source domain')
        item = probe(url)
        entries.append({'number': n, **item})
        if idx < 2 and delay:
            time.sleep(delay)
    success = [x for x in entries if x.get('status') == 'valid_chapter_candidate']
    hashes = {x.get('sha256') for x in success}
    ok = len(success)==3 and len(hashes)==3
    all_blocked = all(x.get('status') in ('cloudflare_access_denied','access_denied') for x in entries)
    return {'seed': seed, 'sampled': selection, 'validated': len(success),
            'blocked': len([x for x in entries if x.get('status') in ('cloudflare_access_denied','access_denied')]),
            'status': 'SAMPLE_PASS' if ok else 'SAMPLE_FAIL',
            'next_gate': ('complete_book_integrity_verification' if ok else
                          'STOP_REPEATED_HTTP_RETRIES_USE_USER_VISIBLE_BROWSER' if all_blocked else
                          'INVESTIGATE_PER_CHAPTER_FAILURES'),
            'chapters': entries}


def write_report(report: dict, file: Path):
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
