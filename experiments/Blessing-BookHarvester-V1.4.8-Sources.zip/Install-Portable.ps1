$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcFolder = Join-Path $here 'BookHarvesterApp'
$srcExe = Join-Path $srcFolder 'BlessingBookHarvester.exe'
$srcEdge = Join-Path $here 'Edge-Extension'
$srcManifest = Join-Path $srcEdge 'manifest.json'
if (!(Test-Path -LiteralPath $srcExe -PathType Leaf) -or !(Test-Path -LiteralPath $srcManifest -PathType Leaf)) {
    throw 'Archive incomplete: BookHarvesterApp\BlessingBookHarvester.exe ou Edge-Extension\manifest.json absent. Extraire tout le ZIP.'
}
$installRoot = Join-Path $env:LOCALAPPDATA 'BlessingBookHarvester'
$targetFolder = Join-Path $installRoot 'app-v1.4.8'
$targetEdge = Join-Path $installRoot 'Chromium-Extension'
New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
New-Item -ItemType Directory -Path $targetEdge -Force | Out-Null
Copy-Item -Path (Join-Path $srcFolder '*') -Destination $targetFolder -Recurse -Force
Copy-Item -Path (Join-Path $srcEdge '*') -Destination $targetEdge -Recurse -Force
$exe = Join-Path $targetFolder 'BlessingBookHarvester.exe'
$report = Join-Path $installRoot 'self-test-1.4.8.json'
if (Test-Path -LiteralPath $report) { Remove-Item -LiteralPath $report -Force }
$p = Start-Process -FilePath $exe -ArgumentList @('--self-test','--ui-probe','--ui-layout-probe','--pipeline-probe','--self-test-report',('"'+$report+'"')) -PassThru
if (-not $p.WaitForExit(40000)) {
    try { $p.Kill() } catch {}
    throw 'Auto-test de lancement superieur a 40 secondes : installation interrompue.'
}
if ($p.ExitCode -ne 0 -or !(Test-Path -LiteralPath $report)) { throw 'Auto-test runtime ou interface refuse : aucun raccourci cree.' }
$probe = Get-Content -Raw -LiteralPath $report | ConvertFrom-Json
if ($probe.ok -ne $true -or $probe.ui -ne 'ok' -or $probe.ui_layout -ne 'ok' -or $probe.pipeline -ne 'ok') { throw 'Le binaire ne peut pas ouvrir sa fenetre sur cet ordinateur.' }
$desktop = [Environment]::GetFolderPath('Desktop')
$link = Join-Path $desktop 'Blessing BookHarvester.lnk'
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($link)
$shortcut.TargetPath = $exe
$shortcut.WorkingDirectory = $targetFolder
$shortcut.Description = 'Blessing BookHarvester V1.4.8 - autonome, un clic, multinavigateur'
$shortcut.Save()
if (!(Test-Path -LiteralPath $link)) { throw 'Impossible de creer le raccourci bureau.' }
Write-Output ('INSTALLED: ' + $exe)
Write-Output ('CHROMIUM_EXTENSION: ' + $targetEdge)
Write-Output ('SHORTCUT: ' + $link)
Write-Output 'Dans Chrome/Edge/Brave/Opera/Vivaldi : Extensions > Mode developpeur > Charger extension decompressee. Pointer vers CHROMIUM_EXTENSION.'
