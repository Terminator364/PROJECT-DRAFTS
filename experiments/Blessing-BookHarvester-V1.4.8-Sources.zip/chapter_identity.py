"""Fail-closed chapter identity checks for legitimate reading imports and QA.

A sufficiently long HTML page is not proof of being the intended chapter.
This module never accesses websites; it only inspects already obtained metadata.
"""
from __future__ import annotations
import re
from urllib.parse import urlsplit

KEYWORD = re.compile(r"(?i)(?:chapter|chapitre|cap[ií]tulo|episode|épisode|глава|chap|ep)\s*[:#№.\-]*\s*(\d{1,5})(?!\d)")
ASIAN = re.compile(r"(?:第\s*(\d{1,5})\s*[章节話话]|제\s*(\d{1,5})\s*화)")
PATH = re.compile(r"(?i)(?:^|/)(?:chapter|chapitre|chap|episode|ep)[-_/]*(\d{1,5})(?:[-_/]|$)")
INDEX = re.compile(r"(?i)\b(?:table of contents|chapter list|all chapters|sommaire|liste des chapitres)\b")


def declared_number(text: str) -> int | None:
    match = KEYWORD.search(text or '')
    if match:
        return int(match.group(1))
    match = ASIAN.search(text or '')
    if match:
        return int(match.group(1) or match.group(2))
    return None


def url_number(url: str) -> int | None:
    match = PATH.search(urlsplit(url).path)
    return int(match.group(1)) if match else None


def check_identity(title: str, *, expected_number: int | None = None, url: str = '') -> dict:
    """Report observed number and confidence; do not silently treat indexes as chapters."""
    page_num = declared_number(title)
    url_num = url_number(url) if url else None
    target = expected_number if expected_number is not None else url_num
    if INDEX.search(title or '') and page_num is None:
        return {'status': 'index_page', 'expected': target, 'observed': page_num}
    if target is not None and page_num is not None and target != page_num:
        return {'status': 'chapter_number_mismatch', 'expected': target, 'observed': page_num}
    if target is not None and url_num is not None and target != url_num:
        return {'status': 'chapter_url_mismatch', 'expected': target, 'observed': url_num}
    if page_num is None:
        return {'status': 'chapter_identity_unverified', 'expected': target, 'observed': None}
    return {'status': 'verified', 'expected': target, 'observed': page_num}


def looks_like_index(page_html: bytes | str) -> bool:
    """Catch tables of contents falsely presented with a valid chapter heading.

    Only classify a page as an index when it links to at least twelve other
    numbered chapters. A novel chapter's two Prev/Next links are not enough.
    """
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(page_html, 'html.parser')
    seen = set()
    for anchor in soup.select('a[href]'):
        target = url_number(anchor.get('href', ''))
        label = declared_number(anchor.get_text(' ', strip=True))
        if target is not None:
            seen.add(target)
        elif label is not None:
            seen.add(label)
    return len(seen) >= 12
