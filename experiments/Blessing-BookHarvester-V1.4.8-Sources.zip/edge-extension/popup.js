const $=id=>document.getElementById(id),JOB='bh_job_v1',CHAPTERS='bh_chapters_v1';
async function active(){let tabs=await chrome.tabs.query({active:true,currentWindow:true});if(!tabs.length)throw Error('Aucun onglet du navigateur');return tabs[0];}
function say(m){$('message').textContent=m||'';}
async function query(type,rest={}){return await chrome.runtime.sendMessage({type,...rest});}
async function refresh(){const r=await query('STATUS');if(!r.ok)throw Error(r.error);const j=r.job;$('status').textContent=j?`${j.state.toUpperCase()} — ${r.chapters} chapitre(s) mémorisé(s)\nProchain : ${j.next} ; objectif : ${j.last} / ${j.expected_end}\n${j.error||''}`:'Aucune collecte démarrée';}
async function startCollection(randomThree=false){
  try {
    say('');const tab=await active();const pattern=$('pattern').value.trim();
    if(!pattern.includes('{n}'))throw Error('URL attendue avec {n}');
    const total=+$('expected').value;
    if(!Number.isInteger(total)||total<3||total>20000)throw Error('Nombre total de chapitres invalide');
    const sample=[];
    if(randomThree){
      // Cryptographic random values, distinct, and never the same fixed test trio.
      while(sample.length<3){const a=new Uint32Array(1);crypto.getRandomValues(a);const n=1+(a[0]%total);if(!sample.includes(n))sample.push(n);}
      sample.sort((a,b)=>a-b);
    }
    const first = randomThree ? sample[0] : +$('first').value;
    const last = randomThree ? sample[2] : +$('last').value;
    const test=new URL(pattern.replace('{n}',String(first)));
    if(test.origin!==new URL(tab.url).origin)throw Error('Ouvre une page sur le même domaine que le roman');
    const granted=await chrome.permissions.request({origins:[test.origin+'/*']});
    if(!granted)throw Error('Autorisation refusée : le navigateur a besoin de l’accès au site');
    const params={book:$('book').value,pattern,first,last,expected:total,tabId:tab.id,delayMs:2500,selectors:[]};
    if(randomThree)params.samples=sample;
    const r=await query('START',{params});if(!r.ok)throw Error(r.error);
    if(randomThree)say('Échantillon sélectionné : '+sample.join(', '));
    await refresh();
  }catch(e){say(String(e.message||e));}
}
$('start').addEventListener('click',()=>startCollection(false));
$('random').addEventListener('click',()=>startCollection(true));
$('pause').addEventListener('click',async()=>{const r=await query('STOP');say(r.error||'Collecte en pause');await refresh();});
$('resume').addEventListener('click',async()=>{try{const tab=await active();const r=await query('RESUME',{tabId:tab.id});if(!r.ok)throw Error(r.error);say('Reprise en cours');await refresh();}catch(e){say(String(e.message||e));}});
$('export').addEventListener('click',async()=>{try{say('');const d=await chrome.storage.local.get([JOB,CHAPTERS]);if(!d[JOB])throw Error('Aucune collecte à exporter');const j=d[JOB],chapters=d[CHAPTERS]||[];if(!chapters.length)throw Error('Aucun chapitre valide');const data={schema:'blessing-bookharvester-edge-v1',book:j.book,origin:j.origin,expected_end:j.expected_end,chapters:chapters.sort((a,b)=>a.number-b.number)};const blob=new Blob([JSON.stringify(data)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='BookHarvester-'+j.book.replace(/[^\p{L}\p{N}_-]/gu,'_').slice(0,40)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),20000);say('Export local prêt ; importer le fichier JSON dans BookHarvester Windows.');}catch(e){say(String(e.message||e));}});
refresh().catch(e=>say(String(e.message||e)));
