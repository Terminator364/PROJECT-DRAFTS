'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'..','edge-extension','background.js'),'utf8');
const file=fs.readFileSync(path.join(__dirname,'..','edge-extension','popup.js'),'utf8');
assert(file.includes('sample.sort') && file.includes("$('random')"));
async function runSample(blockAt=0){
  const storage={};let onMessage,onUpdated;const requests=[];
  const tab={id:44,url:'https://reader.example.org/story/'};
  const chrome={
    storage:{local:{async set(n){Object.assign(storage,n);},async get(k){return Object.fromEntries(k.map(x=>[x,storage[x]]));}}},
    tabs:{onUpdated:{addListener(fn){onUpdated=fn}},async get(id){assert.equal(id,tab.id);return tab},async update(id,p){assert.equal(id,tab.id);tab.url=p.url;requests.push(tab.url);setTimeout(()=>onUpdated(id,{status:'complete'}),3);return tab}},
    scripting:{async executeScript(args){if(args.files)return [{}];const n=Number(tab.url.match(/chapter-(\d+)/)?.[1]);if(n===blockAt)return [{result:{ok:false,error:'Access denied by website'}}];return [{result:{ok:true,title:'Chapter '+n,text:('Actual chapter '+n+' dedicated narrative line. ').repeat(10)}}]}},
    runtime:{onMessage:{addListener(f){onMessage=f}}}
  };
  vm.runInNewContext(code,{chrome,URL,Date,Set,Math,Array,String,Number,Error,Promise,console,setTimeout:(f,ms)=>setTimeout(f,Math.min(ms,2))});
  const message=(type,params)=>new Promise((resolve,reject)=>{onMessage({type,...params},{},resolve);setTimeout(()=>reject(Error('message timed out '+type)),2500)});
  const chosen=[17,91,204];
  const params={book:'Ranovel 236 Random',pattern:'https://reader.example.org/story/chapter-{n}/',first:17,last:204,expected:236,samples:chosen,tabId:44,delayMs:1500};
  const started=await message('START',{params});assert(started.ok,JSON.stringify(started));
  for(let i=0;i<140;i++){
    await new Promise(r=>setTimeout(r,12));
    const job=storage.bh_job_v1;
    if(job?.state===(blockAt?'paused':'done'))break;
  }
  assert.equal(storage.bh_job_v1.state,blockAt?'paused':'done');
  const expected=blockAt?chosen.slice(0,chosen.indexOf(blockAt)):chosen;
  assert.equal(storage.bh_chapters_v1.map(x=>x.number).join(','),expected.join(','));
  const pageIds=requests.map(url=>Number(url.match(/chapter-(\d+)/)?.[1]));
  assert.deepStrictEqual(pageIds,blockAt?[...expected,blockAt]:chosen);
  assert.equal(storage.bh_job_v1.expected_end,236);
}
(async()=>{await runSample();await runSample(91);console.log('PASS Edge/Chromium random nonadjacent sample 17,91,204; stop on blocked page')})().catch(e=>{console.error(e);process.exit(1)});
