import hashlib
import io
import json
from email.message import Message
from unittest.mock import patch
from urllib.error import HTTPError
from pathlib import Path
import pytest
import site_audit as audit
import bookharvester as book

class FakeResponse:
    def __init__(self,status,content=b'',headers=None,url='https://example.org/novel/chapter-12/'):
        self.status = status
        self.code = status
        self.url=url
        self.data=io.BytesIO(content)
        self.headers=Message()
        for k,v in (headers or {}).items():self.headers[k]=v
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def geturl(self):return self.url
    def read(self,n=-1):return self.data.read(n)

def test_cloudflare_403_is_distinguished():
    def opener(req,timeout):return FakeResponse(403,headers={'Server':'cloudflare','CF-Ray':'abc-CGX'})
    r=audit.diagnose_http('https://example.org/novel/chapter-12/',opener=opener)
    assert r['status']=='cloudflare_access_denied'
    assert r['next_gate']=='verify_site_access_and_authorized_use'
    assert 'sha256' not in r

def test_non_cloudflare_403():
    r=audit.diagnose_http('https://example.org/novel/chapter-12/',opener=lambda req,timeout:FakeResponse(403,headers={'Server':'nginx'}))
    assert r['status']=='access_denied'

@pytest.mark.parametrize('code,expected',[(404,'not_found'),(500,'http_unexpected')])
def test_other_status(code,expected):
    r=audit.diagnose_http('https://example.org/novel/chapter-12/',opener=lambda req,timeout:FakeResponse(code))
    assert r['status']==expected

@pytest.mark.parametrize('body,expected',[
    (b'<html><title>Just a moment</title><body>checking your browser</body></html>','challenge_in_200_page'),
    (b'<html><body><nav>Home</nav><main>Index</main></body></html>','html_extraction_failed'),
])
def test_no_false_200(body,expected):
    r=audit.diagnose_http('https://example.org/novel/chapter-12/',opener=lambda req,timeout:FakeResponse(200,body,headers={'Content-Type':'text/html'}))
    assert r['status']==expected

def test_valid_html_and_fingerprint():
    content=b'<html><h1>Chapter 12</h1><div class="chapter-content">'+b'<p>'+(b'Once upon a time. '*20)+b'</p><p>'+(b'The end. '*20)+b'</p></div></html>'
    r=audit.diagnose_http('https://example.org/novel/chapter-12/',opener=lambda req,timeout:FakeResponse(200,content,headers={'Content-Type':'text/html'}))
    assert r['status']=='valid_chapter_candidate'
    assert r['text_length']>160
    assert len(r['sha256'])==64

def test_sample_3_random_blocked_stops_retries():
    def deny(url):return {'url':url,'status':'cloudflare_access_denied','http_status':403}
    r=audit.audit_three('https://example.org/novel/',236,seed=333,delay=0,probe=deny)
    assert len(r['sampled'])==len(set(r['sampled']))==3
    assert r['blocked']==3 and r['validated']==0
    assert r['next_gate']=='STOP_REPEATED_HTTP_RETRIES_USE_USER_VISIBLE_BROWSER'

def test_sample_3_success_distinct():
    def pass_(url):
        n=url.split('chapter-')[-1].split('/')[0]
        return {'url':url,'status':'valid_chapter_candidate','sha256':hashlib.sha256(n.encode()).hexdigest()}
    r=audit.audit_three('https://example.org/novel/',236,seed=7,delay=0,probe=pass_)
    assert r['status']=='SAMPLE_PASS' and r['validated']==3

def test_sample_3_duplicate_body_doesnt_certify():
    def dup(url):return {'url':url,'status':'valid_chapter_candidate','sha256':'1'*64}
    r=audit.audit_three('https://example.org/novel/',236,seed=7,delay=0,probe=dup)
    assert r['status']=='SAMPLE_FAIL'

def test_cli_failed_audit_returns_nonzero(monkeypatch,tmp_path):
    import sys
    monkeypatch.setattr(book,'ROOT',tmp_path)
    monkeypatch.setattr(sys,'argv',['app','--book','Demo','--url','https://example.org/novel/','--count','236','--diagnose-site','--sample-seed','4'])
    with patch.object(audit,'audit_three',return_value={'status':'SAMPLE_FAIL','chapters':[]}):
        with pytest.raises(SystemExit) as exc:book.main()
    assert exc.value.code==5
    assert (tmp_path/'Demo'/'site_diagnostic_report.json').is_file()
