"""Real loopback HTTP integration; no third-party site contacted.

The regular application rejects localhost for safety. Only this hermetic QA test
permits the in-process fixture server (bound to 127.0.0.1). This verifies the
real urllib -> BeautifulSoup -> SQLite -> PDF/EPUB path, not a mocked fetch.
"""
import contextlib
import json
import threading
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import bookharvester as b
from oneclick_pipeline import run_one_click


@contextlib.contextmanager
def web_fixture(block=None):
    requested=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def do_GET(self):
            requested.append(self.path)
            if not self.path.startswith('/book/chapter-'):
                self.send_response(404);self.end_headers();return
            try:n=int(self.path.split('chapter-',1)[1].strip('/'))
            except (ValueError,IndexError):self.send_response(404);self.end_headers();return
            if n==block:
                self.send_response(403)
                self.send_header('Server','cloudflare')
                self.end_headers();return
            body=(f'<html><head><title>Chapter {n}</title></head><body>'
                  f'<article><h1>Chapter {n}</h1><p>'
                  + (f'Real socket transport, a distinct story text for chapter {n}. ' * 18)
                  + '</p></article></body></html>').encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/book/',requested
    finally:
        server.shutdown();server.server_close();worker.join(timeout=3)


def test_one_click_full_book_through_actual_local_http(tmp_path):
    with web_fixture() as (url,visited), patch.object(b,'check_url',side_effect=lambda u:u):
        report=run_one_click('HTTP fixture 12','http://127.0.0.1:'+url.split(':')[2].split('/')[0]+'/book/',12,tmp_path,
                             seed=8,authorized=True,delay=0)
    assert report['status']=='COMPLETE'
    assert report['collected']==12
    assert len(visited)==12 and len(set(visited))==12
    pdf=Path(report['exports']['pdf']);epub=Path(report['exports']['epub'])
    assert pdf.read_bytes().startswith(b'%PDF-')
    with zipfile.ZipFile(epub) as z:
        assert z.testzip() is None
        assert sum(n.startswith('OEBPS/c') and n.endswith('.xhtml') for n in z.namelist())==12


def test_one_click_access_denied_from_actual_http_server(tmp_path):
    # Seed 8 selects [4,6,7] for 12 chapters: block one sampled chapter.
    with web_fixture(block=4) as (url,visited), patch.object(b,'check_url',side_effect=lambda u:u):
        report=run_one_click('HTTP blocked','http://127.0.0.1:'+url.split(':')[2].split('/')[0]+'/book/',12,tmp_path,
                             seed=8,authorized=True,delay=0)
    assert report['status']=='ACCESS_BLOCKED'
    assert report['sample_validated']<3
    assert not list(tmp_path.glob('*.pdf'))
    assert not list(tmp_path.glob('*.epub'))
    assert json.loads((tmp_path/'last_oneclick_report.json').read_text())['status']=='ACCESS_BLOCKED'
