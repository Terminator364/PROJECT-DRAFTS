"""One-click real end-to-end pipeline: three random chapters, all, PDF/EPUB."""
import json
import random
import zipfile
from pathlib import Path
from threading import Event
from unittest.mock import patch

import pytest

import bookharvester as b
from oneclick_pipeline import run_one_click


def sample_html(n: int, book='Approved Example') -> bytes:
    narrative=(f'This is the distinct narrative in chapter {n} of {book}, carrying characters, scenes and action. ' * 8)
    return f'<html><title>Chapter {n}</title><h1>Chapter {n}</h1><article><p>{narrative}</p></article></html>'.encode()


@pytest.mark.parametrize('book,total,seed', [('Alice public-domain test',12,4),('Oz public-domain test',24,9),('Anne public-domain test',41,17)])
def test_three_complete_series_pdf_epub(book,total,seed,tmp_path):
    urls=[];updates=[];root=tmp_path/book
    def fake_fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]);urls.append(n)
        return sample_html(n,book),'text/html'
    with patch.object(b,'fetch',side_effect=fake_fetch):
        result=run_one_click(book,'https://example.org/story/',total,root,seed=seed,authorized=True,delay=0,on_update=updates.append)
    assert result['status']=='COMPLETE'
    assert result['sampled']==sorted(random.Random(seed).sample(range(1,total+1),3))
    assert result['sample_validated']==3
    assert result['collected']==total and result['complete']
    assert len(urls)==total and len(set(urls))==total
    assert Path(result['exports']['pdf']).read_bytes()[:5]==b'%PDF-'
    with zipfile.ZipFile(result['exports']['epub']) as z:
        chapters=[f for f in z.namelist() if f.startswith('OEBPS/c') and f.endswith('.xhtml')]
        assert len(chapters)==total
        assert z.testzip() is None
    report=json.loads((root/'last_oneclick_report.json').read_text())
    assert report['status']=='COMPLETE'
    assert len([a for a in updates if a.get('kind')=='sample'])==3
    assert updates[-1]['status']=='COMPLETE'


def test_oneclick_236_chapters_single_button(tmp_path):
    seen=[]
    def fake_fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]);seen.append(n)
        return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=fake_fetch):
        r=run_one_click('236 authorized fixtures','https://example.org/story/',236,tmp_path,seed=19,authorized=True,delay=0)
    assert r['status']=='COMPLETE' and r['collected']==236
    assert len(seen)==236 and len(set(seen))==236
    with zipfile.ZipFile(r['exports']['epub']) as z:
        assert len([x for x in z.namelist() if x.startswith('OEBPS/c') and x.endswith('.xhtml')])==236


def test_sitewide_403_halts_after_three_without_export(tmp_path):
    seen=[]
    def denied(url,timeout=20):
        seen.append(url)
        raise b.AccessBlocked('HTTP 403 Cloudflare refuse')
    with patch.object(b,'fetch',side_effect=denied):
        r=run_one_click('Rejected','https://example.org/story/',236,tmp_path,authorized=True,delay=0,seed=7)
    assert r['status']=='ACCESS_BLOCKED' and r['collected']==0
    assert r['sample_validated']==0 and r['blocked']==3
    assert len(seen)==3 and len(set(seen))==3
    assert not list(tmp_path.glob('*.pdf')) and not list(tmp_path.glob('*.epub'))
    assert json.loads((tmp_path/'last_oneclick_report.json').read_text())['status']=='ACCESS_BLOCKED'


def test_recovery_after_interruption_downloads_only_missing(tmp_path):
    stop=Event();seen=[];in_sample=set(random.Random(23).sample(range(1,25),3))
    def interrupted(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]); seen.append(n)
        if len(seen)>12:stop.set()
        return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=interrupted):
        first=run_one_click('Recovery Book','https://example.org/story/',24,tmp_path,seed=23,authorized=True,delay=0,stop=stop)
    assert first['status']=='CANCELLED'
    assert first['collected']>=3 and first['collected']<24
    assert not list(tmp_path.glob('*.pdf'))
    stop.clear()
    def resume(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]);seen.append(n)
        return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=resume):
        second=run_one_click('Recovery Book','https://example.org/story/',24,tmp_path,seed=23,authorized=True,delay=0,stop=stop)
    assert second['status']=='COMPLETE'
    assert set(seen)==set(range(1,25))
    # Sample entries and completed chapters aren't downloaded twice.
    assert len(seen)==24


def test_aborted_when_sample_has_wrong_number(tmp_path):
    attempted=[]
    def bad(url,timeout=20):
        attempted.append(url)
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0])
        return sample_html(n+1),'text/html'
    with patch.object(b,'fetch',side_effect=bad):
        r=run_one_click('Wrong Chapter','https://example.org/story/',236,tmp_path,authorized=True,delay=0,seed=12)
    assert r['status']=='SAMPLE_FAILED' and r['collected']==0
    assert len(attempted)==3
    assert not list(tmp_path.glob('*.pdf'))


def test_permission_and_urls_checked_before_network(tmp_path):
    with pytest.raises(PermissionError):run_one_click('No rights','https://example.org/',236,tmp_path)
    with pytest.raises(ValueError):run_one_click('Bad URL','http://localhost/',236,tmp_path,authorized=True)
    with pytest.raises(ValueError):run_one_click('Bad count','https://example.org/',2,tmp_path,authorized=True)


def test_export_failure_keeps_provisional_files_out(tmp_path):
    def fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]);return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=fetch),patch.object(b,'export_pdf',side_effect=RuntimeError('Simulated PDF writing failure')):
        r=run_one_click('Broken PDF','https://example.org/',12,tmp_path,authorized=True,delay=0,seed=6)
    assert r['status']=='ERROR' and r['complete']
    assert not (tmp_path/'Broken-PDF.pdf').exists()
    assert not (tmp_path/'Broken-PDF.epub').exists()
    assert not list(tmp_path.glob('*.temporary.*'))


def test_source_change_under_same_book_cannot_mix_chapters(tmp_path):
    def fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0]);return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=fetch):
        first=run_one_click('Same Title','https://example.org/story/',12,tmp_path,authorized=True,delay=0,seed=5)
        second=run_one_click('Same Title','https://example.net/other/',12,tmp_path,authorized=True,delay=0,seed=6)
    assert first['status']=='COMPLETE'
    assert second['status']=='SOURCE_MISMATCH'
    assert 'source' in second['diagnostic'].lower()


def test_change_of_chapter_url_pattern_is_never_silently_reused(tmp_path):
    seen=[]
    def fetch(url,timeout=20):
        seen.append(url)
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0])
        return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=fetch):
        old=run_one_click('Same book different patterns','https://example.org/story/',12,tmp_path,
                          seed=3,authorized=True,delay=0)
    assert old['status']=='COMPLETE'
    before=list(seen)
    # An alternate chapter URL pattern must not claim that the OLD chapters are a fresh book.
    new=run_one_click('Same book different patterns','https://example.org/story/',12,tmp_path,
                      pattern='episode-{n}/',seed=4,authorized=True,delay=0)
    assert new['status']=='SOURCE_MISMATCH'
    assert seen==before


def test_export_second_file_commit_failure_never_leaves_partial_new_final(tmp_path):
    import oneclick_pipeline as oc
    def fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0])
        return sample_html(n),'text/html'
    original_replace=oc.os.replace
    hit={'commits':0}
    def fail_only_second_published_export(src,dst):
        if str(src).endswith('.temporary.pdf') and str(dst).endswith('.pdf'):
            hit['commits']+=1
            raise OSError('simulated interrupted PDF final publish')
        return original_replace(src,dst)
    with patch.object(b,'fetch',side_effect=fetch),patch.object(oc.os,'replace',side_effect=fail_only_second_published_export):
        r=run_one_click('Publication interrupted','https://example.org/story/',12,tmp_path,
                        seed=9,authorized=True,delay=0)
    assert r['status']=='ERROR'
    assert hit['commits']==1
    assert not (tmp_path/'Publication-interrupted.epub').exists()
    assert not (tmp_path/'Publication-interrupted.pdf').exists()
    assert not list(tmp_path.glob('*.temporary.*'))


def test_failed_republish_preserves_previously_valid_pdf_epub(tmp_path):
    import oneclick_pipeline as oc
    def fetch(url,timeout=20):
        n=int(url.rsplit('chapter-',1)[-1].split('/')[0])
        return sample_html(n),'text/html'
    with patch.object(b,'fetch',side_effect=fetch):
        first=run_one_click('Existing Book','https://example.org/story/',12,tmp_path,
                            seed=4,authorized=True,delay=0)
    assert first['status']=='COMPLETE'
    pdf=Path(first['exports']['pdf']); epub=Path(first['exports']['epub'])
    old_pdf=pdf.read_bytes(); old_epub=epub.read_bytes()
    actual=oc.os.replace
    def fail_pdf(src,dest):
        if str(src).endswith('.temporary.pdf') and dest==pdf:
            raise OSError('simulated interruption during PDF commit')
        return actual(src,dest)
    with patch.object(b,'fetch',side_effect=fetch),patch.object(oc.os,'replace',side_effect=fail_pdf):
        second=run_one_click('Existing Book','https://example.org/story/',12,tmp_path,
                            seed=4,authorized=True,delay=0)
    assert second['status']=='ERROR'
    assert pdf.read_bytes()==old_pdf
    assert epub.read_bytes()==old_epub
    assert not list(tmp_path.glob('*.old-pair'))
