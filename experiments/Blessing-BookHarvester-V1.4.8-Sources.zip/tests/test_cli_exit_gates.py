"""Prevent false green checks when a live website rejects chapter retrieval."""
import sys
from unittest.mock import patch
import pytest
import bookharvester as b

CLI=['blessingbookharvester','--book','No-Copyright-Fixture','--url','https://example.org/story/','--count','236','--permit-archive']

@pytest.mark.parametrize('status,exit_code', [('SAMPLE_FAIL',3), ('SAMPLE_PASS',None)])
def test_random_cli_exit_code(status,exit_code,tmp_path,monkeypatch,capsys):
    monkeypatch.setattr(b,'ROOT',tmp_path)
    monkeypatch.setattr(sys,'argv',CLI+['--sample-three','--sample-seed','42'])
    with patch.object(b,'sample_three_chapters',return_value={'status':status,'validated':3 if status=='SAMPLE_PASS' else 0}):
        if exit_code is not None:
            with pytest.raises(SystemExit) as e:b.main()
            assert e.value.code==exit_code
        else:b.main()
    assert status in capsys.readouterr().out

@pytest.mark.parametrize('reported,code', [({'blocked':True,'failed':1,'remaining':3},4),({'blocked':False,'failed':0,'remaining':0},None),({'blocked':False,'failed':1,'remaining':2},4)])
def test_full_book_cli_exit_code(reported,code,tmp_path,monkeypatch):
    monkeypatch.setattr(b,'ROOT',tmp_path)
    monkeypatch.setattr(sys,'argv',CLI)
    with patch.object(b,'retrieve',return_value=reported):
        if code is not None:
            with pytest.raises(SystemExit) as e:b.main()
            assert e.value.code==code
        else:b.main()
