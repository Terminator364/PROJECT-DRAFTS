import io
from email.message import Message
from pathlib import Path
from urllib.parse import quote
from chapter_identity import declared_number, check_identity, url_number
import bookharvester as bh
import site_audit as audit


def example(n, label=None):
    label = f'Chapter {n}' if label is None else label
    return f'<html><title>{label}</title><h1>{label}</h1><article>' + ('<p>Long novel paragraph.</p>'*25) + '</article></html>'


def test_episode_number_languages():
    assert declared_number('Episode 110 - Lights') == 110
    assert declared_number('Chapitre 23') == 23
    assert declared_number('Глава 12') == 12
    assert declared_number('제 45 화') == 45
    assert declared_number('第 78 章') == 78


def test_url_slug_variations():
    assert url_number('https://example.org/novel/chapter-23/') == 23
    assert url_number('https://example.org/book/chapter-23-new-era/') == 23
    assert url_number('https://example.org/book/chapter-23') == 23


def test_mismatch_rejected():
    assert check_identity('Chapter 3', url='https://example.org/book/chapter-24/')['status'] == 'chapter_number_mismatch'
    assert check_identity('Table of Contents', url='https://example.org/book/chapter-24/')['status'] == 'index_page'
    assert check_identity('I am the Demon Lord', url='https://example.org/book/chapter-24/')['status'] == 'chapter_identity_unverified'


def test_html_import_correct_matching_number(tmp_path):
    inbox=tmp_path/'downloaded';inbox.mkdir()
    (inbox/'chapter_023.html').write_text(example(23),encoding='utf-8')
    results=bh.import_html('Novel',inbox,tmp_path/'library')
    assert results['imported']==[23] and not results['rejected']


def test_html_import_rejects_wrong_number(tmp_path):
    inbox=tmp_path/'downloaded';inbox.mkdir()
    (inbox/'chapter_023.html').write_text(example(24),encoding='utf-8')
    results=bh.import_html('Novel',inbox,tmp_path/'library')
    assert not results['imported'] and results['rejected']


def test_import_rejects_table_of_contents_named_as_chapter(tmp_path):
    inbox=tmp_path/'downloaded';inbox.mkdir()
    (inbox/'chapter_023.html').write_text(example(23,'Table of Contents'),encoding='utf-8')
    results=bh.import_html('Novel',inbox,tmp_path/'library')
    assert not results['imported']


class FakeHttp200:
    status=200
    def __init__(self,html):
        self.raw=io.BytesIO(html.encode('utf-8'))
        self.headers=Message();self.headers['Content-Type']='text/html'
    def __enter__(self):return self
    def __exit__(self,*exc):pass
    def read(self,n=-1):return self.raw.read(n)
    def geturl(self):return 'https://example.org/book/chapter-23/'


def test_diagnostic_catches_html_200_false_positive():
    response=FakeHttp200(example(24))
    result=audit.diagnose_http('https://example.org/book/chapter-23/',opener=lambda req,timeout:response)
    assert result['http_status']==200
    assert result['status']=='chapter_number_mismatch'


def test_diagnostic_stops_unverified_long_homepage():
    response=FakeHttp200(example(23,'Home - Novel list'))
    result=audit.diagnose_http('https://example.org/book/chapter-23/',opener=lambda req,timeout:response)
    assert result['status']=='chapter_identity_unverified'


def test_diagnostic_valid_chapter_number():
    response=FakeHttp200(example(23))
    result=audit.diagnose_http('https://example.org/book/chapter-23/',opener=lambda req,timeout:response)
    assert result['status']=='valid_chapter_candidate'


def test_index_disguised_as_chapter_long_html_is_rejected():
    nav=''.join(f'<a href="chapter-{n}/">Chapter {n}</a>' for n in range(1,50))
    fake=f'<html><h1>Chapter 23</h1><article><p>Table of contents</p>{nav}</article></html>'
    result=audit.diagnose_http('https://example.org/book/chapter-23/',opener=lambda req,timeout:FakeHttp200(fake))
    assert result['status']=='index_page'


def test_real_retrieval_rejects_wrong_story_for_number(monkeypatch,tmp_path):
    # The response is 200 and has long narrative text, but says Chapter 8 at Chapter 23 URL.
    monkeypatch.setattr(bh,'fetch',lambda url,timeout=20:(example(8).encode(),'text/html'))
    report=bh.retrieve('Wrong Page',tmp_path,'https://example.org/book/','novel',count=23,start=23,delay=0,event=lambda _:None)
    assert report['ok']==0 and report['failed']==1
    cat=bh.Catalog(tmp_path/'library.sqlite3')
    try:
        row=cat.chapters('Wrong Page')[0]
        assert row[5]!='ok'
    finally:cat.close()
