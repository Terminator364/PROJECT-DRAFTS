"""Security regression: validate each redirect before any redirected request."""
import io
from unittest.mock import patch
from urllib.error import HTTPError

import pytest

import bookharvester as b


def test_fetch_requires_redirect_safe_opener():
    class Response:
        headers = {'Content-Type':'text/html'}
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def geturl(self): return 'https://novels.example.org/book/chapter-1/'
        def read(self, limit): return b'<html><title>Chapter 1</title><article>' + b'A good sentence. ' * 30 + b'</article>'

    class ControlledOpener:
        def open(self, request, timeout):
            return Response()

    with patch('urllib.request.urlopen', side_effect=AssertionError('unsafe automatic redirect handler used')):
        with patch('urllib.request.build_opener', return_value=ControlledOpener()) as mocked:
            data, mime = b.fetch('https://novels.example.org/book/chapter-1/')
    assert data.startswith(b'<html>')
    assert mime == 'text/html'
    assert any(isinstance(h, b.PublicOnlyRedirectHandler) for h in mocked.call_args.args)


@pytest.mark.parametrize('unsafe', [
    'http://127.0.0.1:8080/private',
    'http://10.0.0.2/config',
    'http://169.254.169.254/latest/meta-data/',
    'http://localhost/admin',
    'http://[::1]:8080/',
    'file:///etc/passwd',
])
def test_redirect_never_opens_private_or_non_http_target(unsafe):
    handler = b.PublicOnlyRedirectHandler()
    from urllib.request import Request
    request = Request('https://novels.example.org/chapter-1/')
    with pytest.raises((ValueError, HTTPError)):
        handler.redirect_request(request, None, 302, 'Found', {}, unsafe)


def test_public_https_redirect_remains_supported():
    from urllib.request import Request
    handler = b.PublicOnlyRedirectHandler()
    original = Request('https://novels.example.org/chapter-1/')
    redir = handler.redirect_request(original, None, 302, 'Found', {}, 'https://novels.example.org/chapter-2/')
    assert redir.full_url == 'https://novels.example.org/chapter-2/'
