"""Regression gate: random three may never certify chapters from another source."""
import random
import pytest
import bookharvester as b


def html(n):
    body=(f'Actual narrative of chapter {n} with unique characters and detail. '*10)
    return f'<html><h1>Chapter {n}</h1><article><p>{body}</p></article></html>'.encode()


def test_random_three_cannot_reuse_stale_chapters_from_another_source(tmp_path):
    seed=19
    first=b.sample_three_chapters('Provenance',tmp_path,'https://source-one.example/book/',24,
        seed=seed,delay=0,fetcher=lambda u:(html(int(u.rsplit('chapter-',1)[-1].strip('/'))),'text/html'),event=lambda _:None)
    assert first['status']=='SAMPLE_PASS'
    visited=[]
    def fake_reader(url):
        visited.append(url)
        return html(int(url.rsplit('chapter-',1)[-1].strip('/'))),'text/html'
    with pytest.raises(ValueError,match='source|provenance|chapitre|origine|patron'):
        b.sample_three_chapters('Provenance',tmp_path,'https://source-two.example/book/',24,
            seed=seed,delay=0,fetcher=fake_reader,event=lambda _:None)
    assert visited==[]


def test_random_three_cannot_reuse_different_url_template(tmp_path):
    seed=37
    b.sample_three_chapters('Provenance',tmp_path,'https://source-one.example/book/',24,
        seed=seed,delay=0,fetcher=lambda u:(html(int(u.rsplit('chapter-',1)[-1].strip('/'))),'text/html'),event=lambda _:None)
    visited=[]
    def reader(url):
        visited.append(url)
        return html(1),'text/html'
    with pytest.raises(ValueError,match='patron|adresse|source|provenance|chapitre'):
        b.sample_three_chapters('Provenance',tmp_path,'https://source-one.example/book/',24,
            seed=seed,pattern='episode-{n}/',delay=0,fetcher=reader,event=lambda _:None)
    assert visited==[]
