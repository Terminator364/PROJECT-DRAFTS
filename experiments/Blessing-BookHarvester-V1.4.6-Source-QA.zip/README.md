# Blessing BookHarvester V1.4 — Multinavigateur / Trois chapitres au hasard

Statut : **candidat QA**. Ne jamais confondre les tests synthétiques avec un téléchargement réussi de Ranovel. Pas de contournement de CAPTCHA, paywall, contrôle d'accès, ni protection technique. Utiliser uniquement pour des pages que vous êtes autorisé à conserver.

## Fonctions

- Collecteur HTTP léger pour des sources publiques qui autorisent l'accès.
- Extension Chromium compatible avec **Microsoft Edge, Google Chrome, Brave, Opera et Vivaldi** (le chargement et l'autorisation des permissions exigent une validation dans le navigateur). Firefox **non validé**.
- **Mode expérimental « 3 chapitres aléatoires »** : 3 numéros distincts entre 1 et le total de chapitres. Leurs textes, longueurs et SHA-256 sont contrôlés individuellement. En cas de HTTP 403/429, l'échec est explicite et enregistré; aucun contournement.
- Reprise SQLite, détection des doublons et de l'intégrité, EPUB/PDF pour romans, CBZ pour pages de manga accessibles.
- Aucune fausse certification : un PDF complet est refusé avant la fin de tous les chapitres; un PDF partiel est clairement étiqueté, et un PDF sans chapitre valide est refusé.

## Installation Windows

1. Télécharger **l'archive Windows créée par un workflow GitHub réussi**, pas le ZIP de code source. Extraire tout.
2. Double-cliquer `Install-Portable.bat` : le script vérifie le démarrage du programme et la fenêtre Tkinter, puis crée **un seul raccourci de bureau**. Sans installation séparée de Python.
3. L'extension se trouve sous `%LOCALAPPDATA%\BlessingBookHarvester\Chromium-Extension`. Dans le navigateur préféré, ouvrir sa page « Extensions », activer le mode développeur puis « Charger extension décompressée » ; accepter l'accès au domaine souhaité.
4. Ouvrir un chapitre réellement accessible dans ce navigateur et cliquer l'extension. Cliquer **🎲 Tester 3 chapitres au hasard**. Si les 3 sont accessibles, exporter le JSON, importer dans BookHarvester Windows et essayer `PDF aperçu partiel`.
5. Pour une récupération complète autorisée, utiliser ensuite la plage 1 → total et contrôler l'inventaire final avant PDF/EPUB complet.

Aucun navigateur particulier n'est requis pour l'application : le mode HTTP et l'import HTML/MHTML peuvent fonctionner sans extension. L'extension Chromium est facultative. Le PC doit être connecté pour la lecture du site, mais la bibliothèque PDF/EPUB fonctionne ensuite hors ligne.

## Automatisation des tests de tirage au sort

Sur une source **librement consultable et autorisée**, le CLI permet un échantillon reproductible :

```powershell
BlessingBookHarvester.exe --book "Livre exemple" --url "https://example.org/novel/" --count 236 --sample-three --sample-seed 20261012 --permit-archive
```

À chaque nouveau cycle, changer la graine. Le rapport `last_random_sample_report.json` liste les trois chapitres essayés, leur état, leurs tailles et leurs empreintes, sans publier les textes sur GitHub.

## Audits / limites

- Base de tests : 31 tests V1.2 + tests sur numéros non consécutifs, reprise, absence de faux PDF, Node.js pour le moteur d'extension, 236 chapitres complets simulés et 3 vrais textes de Project Gutenberg (77 chapitres locaux), puis build et tests Windows sous GitHub.
- **Ranovel n'est pas encore certifié**. Sur GitHub, les chapitres ont renvoyé HTTP 403 dans les tests HTTP/Chrome. Sur le PC MBMPC, les chapitres 175, 195 et 224 ont également renvoyé 403 via HTTP natif. La page du roman, elle, renvoie HTTP 200.
- Le chemin de validation légitime de Ranovel reste une session de navigateur dans laquelle ces pages s'affichent réellement, puis le test de trois chapitres et de leurs exports, suivi du contrôle des 236. Si le site bloque l'accès, aucune simulation ne peut faire croire que les 236 chapitres ont été récupérés.
- GitHub Actions doit rester sur déclenchement manuel après la qualification, en respectant `AGENTS.md` / `CI_BUDGET_POLICY.json` du dépôt.

## Cycle V1.4.6 — fail-closed chapter identity gate (2026-10-12)

**Status:** source candidate validated locally; NOT certified for live Ranovel, Windows build of this revision pending.

Root-cause test failures reproduced before fixes:
1. A `200 OK` chapter URL could carry a long table of contents but still be accepted as a chapter (wrong PDF content).
2. Browser extension could accept Chapter 92 when the URL requested Chapter 91 (wrong chapter order).
3. A downloaded `chapter_023.html` could contain the text of Chapter 24 (wrong user-import mapping).
4. An HTTP chapter URL `chapter-23/` could return a different chapter while the extractor marked it successful.

Changes:
- Python `chapter_identity.py`: verifies stated chapter number from headings in different languages; detects indexes containing 12+ chapter links.
- `site_audit.py`: `200 OK` is classified as verified chapter / mismatched chapter / index / unverified identity, never automatic success on text length alone; CF 403 is recorded without assuming a human challenge will resolve it.
- Browser-independent local `.html` / `.mhtml` imports reject explicitly mislabeled chapters and index pages; works for saved pages from Windows Edge, Chrome, Brave, Opera, Falkon, Firefox, or other browsers supporting HTML save.
- Chromium extension stops on mismatched chapter identity or exact duplicate text across chapter numbers, preserving already collected chapters.
- HTTP retrieval and random-sampling paths reject mislabeled chapters and long index pages.
- Python suite: **69 passed**; Node tests for extension navigation, resume, random three and a deliberately mislabeled chapter also passed. Two negative tests first failed on the old logic and passed after corrections.

**Ranovel access gate:** Cloudflare returned 403 on chapter URLs in independent hosted and MBMPC attempts. A legitimate browser challenge, if ever presented, must be handled by the user; a Cloudflare WAF/IP rule might not offer any human challenge. An interactive browser login or clearance also does not grant license to mass copy; Ranovel terms prohibit copying/reproduction. Do not repeat unchanged blocked requests or promise 236 chapters without publisher/source authorization. No third-party novel text is packaged or published.

**CI budget:** follow `PROJECT-DRAFTS/AGENTS.md` (manual workflow by default). Never automatically run a workflow on every commit.
