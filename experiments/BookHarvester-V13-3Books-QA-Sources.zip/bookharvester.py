"""Blessing BookHarvester: local-first text/image chapter archiver.

Only fetch content the reader is permitted to archive. No bypass of site controls.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import json
import logging
import os
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from threading import Event
from typing import Callable

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

VERSION = "1.3.0-multibrowser-qa"
ROOT = Path(os.environ.get("BOOKHARVESTER_HOME", str(Path.home() / "Documents" / "Blessing BookHarvester")))
DEFAULT_SELECTORS = [
    ".reading-content", ".chapter-content", "#chapter-content", ".entry-content",
    ".chapter-reading", ".text-left", ".read-content", "article", "main",
]
IMAGE_SELECTORS = [".reading-content img", "#chapter-images img", ".chapter-content img", ".wp-manga-chapter-img", "article img"]
STOP_TAGS = "script,style,noscript,nav,footer,header,aside,form,button,iframe"
BAD_MARKERS = ("checking your browser", "verify you are human", "access denied", "just a moment", "cf-challenge", "captcha")
USER_AGENT = "BlessingBookHarvester/1.0 (personal offline reading backup; requests spaced)"
log = logging.getLogger("bookharvester")


class RetrievalError(Exception):
    """Non-permanent network or parsing failure."""


class AccessBlocked(RetrievalError):
    """Do not retry a site access restriction automatically."""


def safe_slug(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip()).strip("-")[:70] or "book"


def check_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Seules les adresses publiques HTTP/HTTPS sont acceptées")
    host = parsed.hostname.casefold()
    if host in ("localhost",) or host.endswith((".localhost", ".local", ".internal")):
        raise ValueError("Adresse locale non autorisée")
    import ipaddress
    try:
        if not ipaddress.ip_address(host).is_global:
            raise ValueError("Adresse réseau privée/réservée non autorisée")
    except ValueError as exc:
        if "non autorisée" in str(exc):
            raise
    return url


def canonical(url: str) -> str:
    p = urllib.parse.urlsplit(check_url(url))
    return urllib.parse.urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path.rstrip("/") + "/", p.query, ""))


def fetch(url: str, timeout: int = 20) -> tuple[bytes, str]:
    check_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,image/*;q=0.8"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            check_url(response.geturl())
            data = response.read(15 * 1024 * 1024 + 1)
            if len(data) > 15 * 1024 * 1024:
                raise RetrievalError("Réponse trop volumineuse (> 15 Mo)")
            return data, response.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403, 407, 429, 451):
            raise AccessBlocked(f"HTTP {exc.code} : accès restreint; aucune tentative de contournement") from exc
        raise RetrievalError(f"HTTP {exc.code} pour {url}") from exc
    except (OSError, TimeoutError) as exc:
        raise RetrievalError(f"Réseau : {exc}") from exc


def soup_from(content: bytes | str):
    if BeautifulSoup is None:
        raise RuntimeError("Installer les dépendances : python -m pip install -r requirements.txt")
    return BeautifulSoup(content, "html.parser")


def detect_block(page) -> None:
    page_title = page.title.get_text(" ", strip=True).lower() if page.title else ""
    content = (page_title + " " + page.get_text(" ", strip=True)[:900]).lower()
    if any(x in content for x in BAD_MARKERS):
        raise AccessBlocked("Page de vérification/restriction détectée; ouvrir légalement dans le navigateur")


def extract_text(page_html: bytes | str, selectors: list[str] | None = None, min_chars: int = 80) -> tuple[str, str]:
    page = soup_from(page_html)
    detect_block(page)
    title_element = page.select_one("h1") or page.title
    title = title_element.get_text(" ", strip=True) if title_element else "Chapitre"
    selectors = selectors or DEFAULT_SELECTORS
    candidates = [(len(el.get_text(" ", strip=True)), el) for sel in selectors for el in page.select(sel)]
    if not candidates:
        raise RetrievalError("Zone de lecture introuvable : ajouter un sélecteur CSS au profil")
    content = max(candidates, key=lambda pair: pair[0])[1]
    for unwanted in content.select(STOP_TAGS + ",.ads,.advertisement,.adsbygoogle,.sharedaddy,.chapter-nav"):
        unwanted.decompose()
    # Preserve paragraph/newline breaks without including navigation as narrative.
    for block in content.find_all(["p", "br", "div", "h2", "h3", "li"]):
        if block.name == "br":
            block.replace_with("\n")
        elif block.string is not None:
            block.string.replace_with(block.string + "\n")
        else:
            block.append("\n")
    raw = content.get_text(" ", strip=False).replace("\xa0", " ")
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in raw.splitlines()]
    text = "\n".join(line for line in lines if line)
    if len(text) < min_chars:
        raise RetrievalError(f"Texte insuffisant ({len(text)} caractères) : page non validée")
    return title, text


def extract_images(page_html: bytes | str, page_url: str, selectors: list[str] | None = None) -> list[str]:
    page = soup_from(page_html)
    detect_block(page)
    images: list[str] = []
    for sel in selectors or IMAGE_SELECTORS:
        for tag in page.select(sel):
            src = next((tag.get(key) for key in ("data-src", "data-lazy-src", "data-original", "src") if tag.get(key)), None)
            if src and not src.startswith("data:"):
                url = urllib.parse.urljoin(page_url, src.strip())
                try:
                    check_url(url)
                except ValueError:
                    continue
                if url not in images:
                    images.append(url)
        if images:
            return images
    raise RetrievalError("Aucune planche trouvée; ajouter un sélecteur image au profil")


def discover(page_html: bytes | str, base_url: str) -> list[tuple[int, str]]:
    page = soup_from(page_html)
    detect_block(page)
    found: dict[int, str] = {}
    base_host = urllib.parse.urlparse(base_url).hostname
    for a in page.select("a[href]"):
        url = urllib.parse.urljoin(base_url, a["href"])
        if urllib.parse.urlparse(url).hostname != base_host:
            continue
        title = a.get_text(" ", strip=True)
        match = re.search(r"(?:chapter|chapitre|chap|ch)[-_/\s]*(\d{1,5})(?:/|\b)", urllib.parse.urlparse(url).path, re.I)
        if not match:
            match = re.search(r"(?:chapter|chapitre)\s*(\d{1,5})\b", title, re.I)
        if match:
            found[int(match.group(1))] = canonical(url)
    return sorted(found.items())


def urls_by_pattern(base: str, count: int, first: int = 1, pattern: str = "chapter-{n}/") -> list[tuple[int, str]]:
    """Only constructs candidate URLs; HTTP checks happen before acceptance."""
    if not 1 <= count <= 20000 or not 1 <= first <= count or "{n}" not in pattern:
        raise ValueError("Nombre de chapitres, début ou patron d'URL invalide")
    base = canonical(base)
    return [(n, urllib.parse.urljoin(base, pattern.format(n=n))) for n in range(first, count + 1)]


class Catalog:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS books (
                book TEXT PRIMARY KEY, expected_end INTEGER NOT NULL DEFAULT 0,
                source TEXT DEFAULT '', updated_at TEXT DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS chapters (
                book TEXT NOT NULL, number INTEGER NOT NULL, url TEXT NOT NULL,
                title TEXT DEFAULT '', body TEXT DEFAULT '', kind TEXT DEFAULT 'novel',
                status TEXT NOT NULL DEFAULT 'pending', sha256 TEXT DEFAULT '', error TEXT DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT '', PRIMARY KEY(book,number)
            );
            CREATE TABLE IF NOT EXISTS images (
                book TEXT NOT NULL, chapter INTEGER NOT NULL, position INTEGER NOT NULL,
                path TEXT NOT NULL, sha256 TEXT NOT NULL,
                PRIMARY KEY(book,chapter,position)
            );
        """)
        self.connection.commit()

    def close(self):
        self.connection.close()

    def plan(self, book: str, urls: list[tuple[int, str]], kind: str, expected_end: int = 0):
        with self.connection:
            self.connection.execute("INSERT OR IGNORE INTO books(book,expected_end) VALUES(?,0)", (book,))
            if expected_end:
                self.connection.execute("UPDATE books SET expected_end=MAX(expected_end,?) WHERE book=?", (expected_end,book))
            for number, url in urls:
                self.connection.execute("""INSERT OR IGNORE INTO chapters(book,number,url,kind) VALUES(?,?,?,?)""", (book, number, url, kind))

    def chapters(self, book: str):
        return self.connection.execute("SELECT number,url,title,body,kind,status,sha256,error FROM chapters WHERE book=? ORDER BY number", (book,)).fetchall()

    def complete(self, book: str, number: int, title: str, body: str, kind: str, digest: str):
        with self.connection:
            self.connection.execute("""UPDATE chapters SET title=?,body=?,kind=?,status='ok',sha256=?,error='',updated_at=? WHERE book=? AND number=?""",
                (title, body, kind, digest, dt.datetime.now(dt.timezone.utc).isoformat(), book, number))

    def failed(self, book: str, number: int, err: str):
        with self.connection:
            self.connection.execute("UPDATE chapters SET status='failed',error=? WHERE book=? AND number=?", (err[:350], book, number))

    def save_image(self, book: str, number: int, pos: int, path: Path, digest: str):
        with self.connection:
            self.connection.execute("INSERT OR REPLACE INTO images(book,chapter,position,path,sha256) VALUES(?,?,?,?,?)", (book, number, pos, str(path), digest))

    def images(self, book: str):
        return self.connection.execute("SELECT chapter,position,path,sha256 FROM images WHERE book=? ORDER BY chapter,position", (book,)).fetchall()


def retrieve(book: str, root: Path, url: str, mode: str, count: int = 0, start: int = 1,
             pattern: str = "chapter-{n}/", delay: float = 2.0,
             event: Callable[[str], None] = print, stop: Event | None = None,
             profile: dict | None = None, first_html: bytes | None = None,
             targets: list[tuple[int,str]] | None = None) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    profile = profile or {}
    if targets is not None:
        # Table-of-contents sources may use non-numeric URLs (roman numerals,
        # page numbers, slugs). Only accept a complete, ordered same-origin plan.
        targets = list(targets)
        nums = [n for n, u in targets]
        if not nums or nums != list(range(1, len(targets)+1)) or len(targets) > 20000:
            raise ValueError("Table des matières incomplète, non contiguë ou trop longue")
        origin = urllib.parse.urlsplit(check_url(url)).netloc.lower()
        for n, link in targets:
            if urllib.parse.urlsplit(check_url(link)).netloc.lower() != origin:
                raise ValueError("Chapitre hors du domaine de la série")
    elif count:
        targets = urls_by_pattern(url, count, start, pattern)
    else:
        page = first_html if first_html is not None else fetch(url)[0]
        targets = discover(page, url)
        if not targets:
            raise RetrievalError("Aucun chapitre découvert; renseigner total et patron d'URL")
    catalog = Catalog(root / "library.sqlite3")
    catalog.plan(book, targets, mode, expected_end=(len(targets) if not count else count))
    events = {"ok": 0, "skipped": 0, "failed": 0, "blocked": False, "planned": len(targets)}
    files = root / "images" / safe_slug(book)
    lookup = {r[0]: r for r in catalog.chapters(book)}
    def emit(message: str):
        with (root / "bookharvester.log").open("a", encoding="utf-8") as stream:
            stream.write(dt.datetime.now(dt.timezone.utc).isoformat() + " " + message + "\n")
        event(message)
    for number, chapter_url in targets:
        if stop and stop.is_set():
            emit("Arrêt demandé : les chapitres déjà acquis sont sauvegardés")
            break
        row = lookup.get(number)
        if row and row[5] == "ok":
            events["skipped"] += 1
            continue
        try:
            emit(f"Chapitre {number} : récupération…")
            raw, ct = fetch(chapter_url)
            if "text/html" not in ct.lower() and "application/xhtml" not in ct.lower() and ct:
                raise RetrievalError("La réponse n'est pas une page HTML")
            if mode == "novel":
                title, body = extract_text(raw, profile.get("text_selectors"))
                digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
                catalog.complete(book, number, title, body, mode, digest)
            else:
                links = extract_images(raw, chapter_url, profile.get("image_selectors"))
                files.mkdir(parents=True, exist_ok=True)
                digest_hash = hashlib.sha256()
                for pos, link in enumerate(links, 1):
                    binary, content_type = fetch(link)
                    if not content_type.lower().startswith("image/") or len(binary) < 64:
                        raise RetrievalError(f"Planche {pos} invalide : {link}")
                    suffix = {"image/png": ".png", "image/webp": ".webp", "image/jpeg": ".jpg", "image/gif": ".gif"}.get(content_type.split(";")[0].strip().lower(), ".img")
                    path = files / f"ch{number:05d}_{pos:04d}{suffix}"
                    path.write_bytes(binary)
                    digest = hashlib.sha256(binary).hexdigest()
                    digest_hash.update(digest.encode("ascii"))
                    catalog.save_image(book, number, pos, path, digest)
                    if delay:
                        time.sleep(delay)
                catalog.complete(book, number, f"Chapitre {number}", str(len(links)), mode, digest_hash.hexdigest())
            events["ok"] += 1
            emit(f"Chapitre {number} : validé et sauvegardé")
        except AccessBlocked as exc:
            catalog.failed(book, number, str(exc))
            emit(f"BLOCAGE chapitre {number} : {exc}")
            events["blocked"] = True
            events["failed"] += 1
            break
        except (RetrievalError, ValueError, OSError) as exc:
            catalog.failed(book, number, str(exc))
            emit(f"ERREUR chapitre {number} : {exc}")
            events["failed"] += 1
        if delay:
            time.sleep(delay)
    events["remaining"] = len([r for r in catalog.chapters(book) if r[5] != "ok"])
    (root / "last_report.json").write_text(json.dumps({"book": book, "url": url, **events}, indent=2, ensure_ascii=False), encoding="utf-8")
    catalog.close()
    return events


def import_html(book: str, folder: Path, root: Path, selectors: list[str] | None = None) -> dict:
    """Fallback for the user's own Chrome saved .html and .mhtml pages."""
    import email
    cat = Catalog(root / "library.sqlite3")
    done = []
    bad = []
    for path in sorted(folder.glob("*")):
        if path.suffix.lower() not in (".html", ".htm", ".mhtml", ".mht"):
            continue
        m = re.search(r"(?:chapter|chapitre|ch)[_\s-]*(\d+)", path.stem, re.I)
        if not m:
            bad.append(f"{path.name}: numéro absent")
            continue
        n = int(m.group(1))
        try:
            data = path.read_bytes()
            if path.suffix.lower() in (".mhtml", ".mht"):
                msg = email.message_from_bytes(data)
                part = next((p for p in msg.walk() if p.get_content_type() == "text/html"), None)
                if part is None:
                    raise RetrievalError("Aucun contenu HTML dans le MHTML")
                data = part.get_payload(decode=True)
            title, body = extract_text(data, selectors)
            cat.plan(book, [(n, path.as_uri())], "novel")
            cat.complete(book, n, title, body, "novel", hashlib.sha256(body.encode()).hexdigest())
            done.append(n)
        except Exception as exc:
            bad.append(f"{path.name}: {exc}")
    cat.close()
    return {"imported": done, "rejected": bad}


def inventory(cat: Catalog, book: str) -> dict:
    rows = cat.chapters(book)
    numbers = [r[0] for r in rows]
    record = cat.connection.execute("SELECT expected_end FROM books WHERE book=?",(book,)).fetchone()
    expected_end = record[0] if record else 0
    missing = [n for n in range(1, expected_end + 1) if n not in numbers] if expected_end else []
    failed = [r[0] for r in rows if r[5] != "ok"]
    bad_hash = [r[0] for r in rows if r[5] == "ok" and r[4] == "novel" and hashlib.sha256(r[3].encode()).hexdigest() != r[6]]
    seen_hashes = set()
    duplicates = []
    for r in rows:
        if r[5] == "ok" and r[4] == "novel":
            if r[6] in seen_hashes:
                duplicates.append(r[0])
            seen_hashes.add(r[6])
    return {"total": len(rows), "expected": expected_end, "ok": len(rows)-len(failed), "pending": failed, "holes": missing, "integrity_errors": bad_hash, "duplicates": duplicates, "complete": bool(rows) and expected_end > 0 and not (missing or failed or bad_hash or duplicates)}


def _ensure_exportable(cat: Catalog, book: str, allow_partial: bool) -> tuple[list, dict]:
    rows = cat.chapters(book)
    inv = inventory(cat, book)
    if not rows:
        raise ValueError("Aucun chapitre présent")
    if not allow_partial and not inv["complete"]:
        raise ValueError("Export incomplet refusé : chapitres manquants/échoués ou intégrité incorrecte")
    return [r for r in rows if r[5] == "ok" and r[0] not in inv["integrity_errors"]], inv


def export_epub(book: str, root: Path, dest: Path, allow_partial: bool = False) -> Path:
    cat = Catalog(root / "library.sqlite3")
    try:
        rows, inv = _ensure_exportable(cat, book, allow_partial)
    finally:
        cat.close()
    if any(r[4] != "novel" for r in rows):
        raise ValueError("EPUB texte disponible seulement pour les romans")
    manifest = []
    nav = []
    spine = []
    with zipfile.ZipFile(dest, "w") as z:
        z.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
        z.writestr("OEBPS/style.css", "body{line-height:1.55;margin:1em}h1{page-break-before:always}p{margin:0 0 0.8em}")
        manifest.append('<item id="css" href="style.css" media-type="text/css"/>')
        for n, _url, title, body, _kind, _status, _hash, _err in rows:
            key = f"c{n:05d}"
            filename = f"{key}.xhtml"
            paragraphs = "".join("<p>"+html.escape(para).replace("\n", "<br/>")+"</p>" for para in body.split("\n\n") if para.strip())
            chapter = f'<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>{html.escape(title)}</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body><h1>{html.escape(title)}</h1>{paragraphs}</body></html>'
            z.writestr(f"OEBPS/{filename}", chapter, compress_type=zipfile.ZIP_DEFLATED)
            manifest.append(f'<item id="{key}" href="{filename}" media-type="application/xhtml+xml"/>')
            nav.append(f'<li><a href="{filename}">{html.escape(title)}</a></li>')
            spine.append(f'<itemref idref="{key}"/>')
        status = " (INCOMPLET)" if not inv["complete"] else ""
        z.writestr("OEBPS/nav.xhtml", f'<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>Sommaire</title></head><body><nav epub:type="toc" id="toc"><h1>Sommaire</h1><ol>{"".join(nav)}</ol></nav></body></html>')
        manifest.append('<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>')
        z.writestr("OEBPS/content.opf", f'<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="uid">urn:bookharvester:{safe_slug(book)}</dc:identifier><dc:title>{html.escape(book+status)}</dc:title><dc:language>en</dc:language></metadata><manifest>{"".join(manifest)}</manifest><spine>{"".join(spine)}</spine></package>')
    return dest


def export_pdf(book: str, root: Path, dest: Path, allow_partial: bool = False) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A5
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak, Spacer
    from reportlab.lib.units import cm
    cat = Catalog(root / "library.sqlite3")
    try:
        rows, inv = _ensure_exportable(cat, book, allow_partial)
    finally:
        cat.close()
    if any(r[4] != "novel" for r in rows):
        raise ValueError("PDF texte disponible seulement pour les romans")
    fonts = [Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "malgun.ttf", Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "arial.ttf", Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    font = "Helvetica"
    for candidate in fonts:
        if candidate.exists():
            try:
                pdfmetrics.registerFont(TTFont("BookHarvesterBody", str(candidate)))
                font = "BookHarvesterBody"
                break
            except Exception:
                pass
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="BHTitle", fontName=font, fontSize=18, alignment=TA_CENTER, leading=25, spaceAfter=24))
    styles.add(ParagraphStyle(name="BHChapter", fontName=font, fontSize=14, leading=19, spaceAfter=16))
    styles.add(ParagraphStyle(name="BHBody", fontName=font, fontSize=9.5, leading=15, spaceAfter=9))
    doc = SimpleDocTemplate(str(dest), pagesize=A5, leftMargin=1.5*cm, rightMargin=1.5*cm, topMargin=1.6*cm, bottomMargin=1.4*cm)
    story = [Spacer(1, 2*cm), Paragraph(html.escape(book), styles["BHTitle"]), Paragraph(f"{len(rows)} chapitres - {'COMPLET' if inv['complete'] else 'INCOMPLET'}", styles["BHBody"]), PageBreak()]
    for i, (n, _url, title, body, _kind, _status, _hash, _err) in enumerate(rows):
        if i:
            story.append(PageBreak())
        story.append(Paragraph(html.escape(title or f"Chapitre {n}"), styles["BHChapter"]))
        for para in body.split("\n"):
            if para.strip():
                story.append(Paragraph(html.escape(para), styles["BHBody"]))
    def footer(canvas, document):
        canvas.setFont(font, 8)
        canvas.setFillColor(colors.grey)
        canvas.drawCentredString(A5[0]/2, 0.85*cm, str(document.page))
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return dest


def export_cbz(book: str, root: Path, dest: Path, allow_partial: bool = False) -> Path:
    cat = Catalog(root / "library.sqlite3")
    try:
        _rows, inv = _ensure_exportable(cat, book, allow_partial)
        image_rows = cat.images(book)
    finally:
        cat.close()
    if not image_rows:
        raise ValueError("Aucune planche archivée")
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_STORED) as z:
        for chapter, position, filename, digest in image_rows:
            path = Path(filename)
            if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ValueError(f"Image manquante/corrompue {filename}")
            z.write(path, arcname=f"{chapter:05d}/{position:04d}{path.suffix}")
    return dest


def build_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from threading import Thread
    from queue import Queue, Empty

    window = tk.Tk()
    window.title("Blessing BookHarvester V1.3 — Multinavigateur")
    window.geometry("830x620")
    window.minsize(650, 510)
    url = tk.StringVar(value="https://ranovel.com/novel/i-am-the-demon-lord/")
    name = tk.StringVar(value="I Am the Demon Lord")
    kind = tk.StringVar(value="novel")
    number = tk.StringVar(value="236")
    pattern = tk.StringVar(value="chapter-{n}/")
    summary = tk.StringVar(value="Prêt — aucune récupération réelle n'a encore été validée")
    stop = Event()
    messages = Queue()

    ttk.Label(window,text="BOOKHARVESTER  |  EDGE + IMPORT",font=("Segoe UI",15,"bold")).pack(anchor="w",padx=14,pady=(12,5))
    frame = ttk.Frame(window,padding=(14,5))
    frame.pack(fill="x")
    for row,(label,variable) in enumerate((("URL du roman / manga",url),("Titre de la bibliothèque",name),("Total de chapitres attendus",number),("Patron HTTP ({n})",pattern))):
        ttk.Label(frame,text=label).grid(row=row,column=0,sticky="w",pady=5)
        ttk.Entry(frame,textvariable=variable,width=65).grid(row=row,column=1,sticky="ew",pady=5,padx=8)
    frame.columnconfigure(1,weight=1)
    ttk.Radiobutton(frame,text="Roman / texte",variable=kind,value="novel").grid(row=4,column=1,sticky="w")
    ttk.Radiobutton(frame,text="Manga / images",variable=kind,value="manga").grid(row=5,column=1,sticky="w")
    ttk.Label(window,textvariable=summary).pack(anchor="w",padx=15,pady=6)
    output = tk.Text(window,height=13,wrap="word",font=("Consolas",9))
    output.pack(fill="both",expand=True,padx=14,pady=4)
    toolbar = ttk.Frame(window,padding=(12,5))
    toolbar.pack(fill="x")
    outputs = ttk.Frame(window,padding=(12,5))
    outputs.pack(fill="x")
    buttons=[]

    def add_message(s): messages.put(('log',str(s)))
    def send_summary(s): messages.put(('summary',str(s)))
    def set_idle(): messages.put(('idle',None))
    def pump():
        try:
            while True:
                typ,payload=messages.get_nowait()
                if typ=='log': output.insert('end',payload+'\n');output.see('end')
                elif typ=='summary': summary.set(payload)
                elif typ=='idle':
                    for button in buttons:button.configure(state='normal')
        except Empty: pass
        window.after(100,pump)

    def run_async(fn):
        stop.clear()
        for button in buttons:button.configure(state='disabled')
        def runner():
            try:fn()
            except Exception as exc:add_message('ERREUR : '+str(exc))
            finally:set_idle()
        Thread(target=runner,daemon=True).start()

    def new_button(target,label,callback):
        btn=ttk.Button(target,text=label,command=callback)
        btn.pack(side='left',padx=3)
        buttons.append(btn)

    def params():
        title=name.get().strip()
        if not title: raise ValueError('Titre vide')
        total=int(number.get())
        if total<0 or total>20000:raise ValueError('Total de chapitres invalide')
        return title, ROOT/safe_slug(title), total, kind.get()

    def do_download():
        try:title,root,total,mode=params(); link=url.get().strip();template=pattern.get().strip()
        except Exception as exc:messagebox.showerror('Paramètres',str(exc));return
        if not messagebox.askyesno('Autorisation','Confirme que tu es autorisé à enregistrer ce contenu pour ton usage personnel.'):return
        def job():
            result=retrieve(title,root,link,mode,count=total,pattern=template,event=add_message,stop=stop)
            add_message('BILAN : '+json.dumps(result,ensure_ascii=False))
            send_summary(f"{result['ok']} nouveaux; {result['skipped']} déjà enregistrés; {result['remaining']} non validés")
        run_async(job)

    def do_import_html():
        source=filedialog.askdirectory(title='Sélectionner les pages HTML/MHTML sauvegardées')
        if not source:return
        try:title,root,total,mode=params()
        except Exception as exc:messagebox.showerror('Paramètres',str(exc));return
        def job():
            if total:
                cat=Catalog(root/'library.sqlite3')
                try:cat.plan(title,[],mode,expected_end=total)
                finally:cat.close()
            result=import_html(title,Path(source),root)
            cat=Catalog(root/'library.sqlite3')
            try:inv=inventory(cat,title)
            finally:cat.close()
            add_message('IMPORT HTML : '+json.dumps(result,ensure_ascii=False))
            send_summary(f"{inv['ok']} chapitres enregistrés ; {'COMPLET' if inv['complete'] else 'INCOMPLET'}")
        run_async(job)

    def do_import_edge():
        source=filedialog.askopenfilename(title='Fichier de collecte Microsoft Edge',filetypes=[('BookHarvester Edge JSON','*.json')])
        if not source:return
        try:title,root,total,mode=params()
        except Exception as exc:messagebox.showerror('Paramètres',str(exc));return
        if mode!='novel':messagebox.showerror('Format','Le pont Edge V1.2 ne gère actuellement que les romans en texte.');return
        def job():
            from edge_bundle import import_edge_bundle
            result=import_edge_bundle(Path(source),root,expected_book=title)
            add_message('IMPORT EDGE : '+json.dumps({k:v for k,v in result.items() if k!='inventory'},ensure_ascii=False))
            inv=result['inventory']
            add_message(f"CONTROLE : {inv['ok']}/{inv['expected']} | trous={len(inv['holes'])} | conflits={len(result['conflicts'])}")
            send_summary(f"{inv['ok']}/{inv['expected']} validés ; {'COMPLET' if inv['complete'] else 'INCOMPLET'}")
        run_async(job)

    def do_export(fmt,allow_partial=False):
        try:title,root,total,mode=params()
        except Exception as exc:messagebox.showerror('Paramètres',str(exc));return
        def job():
            cat=Catalog(root/'library.sqlite3')
            try:inv=inventory(cat,title)
            finally:cat.close()
            if not allow_partial and not inv['complete']:
                add_message('EXPORT REFUSÉ : '+str(inv['ok'])+'/'+str(inv['expected'])+' ; collection encore incomplète')
                return
            filename=safe_slug(title)+('-PARTIEL' if allow_partial and not inv['complete'] else '')+'.'+fmt
            dest=root/filename
            (export_pdf if fmt=='pdf' else export_epub if fmt=='epub' else export_cbz)(title,root,dest,allow_partial=allow_partial)
            add_message('FICHIER CRÉÉ : '+str(dest))
            send_summary(('APERÇU INCOMPLET' if allow_partial and not inv['complete'] else 'EXPORT COMPLET')+' : '+str(dest))
            if hasattr(os,'startfile'):os.startfile(str(root))
        run_async(job)

    def open_edge_help():
        import subprocess
        try:subprocess.Popen(['msedge.exe','edge://extensions'])
        except OSError:add_message('Ouvre edge://extensions manuellement dans Microsoft Edge.')
        add_message('Edge : activer Mode développeur > Charger extension décompressée > '+str(Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'BlessingBookHarvester' / 'Edge-Extension'))

    new_button(toolbar,'Télécharger HTTP',do_download)
    new_button(toolbar,'Importer Edge JSON',do_import_edge)
    new_button(toolbar,'Importer HTML',do_import_html)
    new_button(toolbar,'Configurer Edge',open_edge_help)
    ttk.Button(toolbar,text='Arrêter',command=stop.set).pack(side='right',padx=3)
    new_button(outputs,'PDF complet',lambda:do_export('pdf'))
    new_button(outputs,'EPUB complet',lambda:do_export('epub'))
    new_button(outputs,'CBZ complet',lambda:do_export('cbz'))
    new_button(outputs,'PDF aperçu partiel',lambda:do_export('pdf',allow_partial=True))
    pump()
    window.mainloop()


def main():
    parser=argparse.ArgumentParser(description="Blessing BookHarvester — archive personnelle, avec autorisation")
    parser.add_argument("--gui",action="store_true")
    parser.add_argument("--url")
    parser.add_argument("--book",default="Mon livre")
    parser.add_argument("--count",type=int,default=0)
    parser.add_argument("--pattern",default="chapter-{n}/")
    parser.add_argument("--mode",choices=("novel","manga"),default="novel")
    parser.add_argument("--delay",type=float,default=2.0)
    parser.add_argument("--profile",type=Path,help="Profil JSON: text_selectors/image_selectors")
    parser.add_argument("--export",choices=("pdf","epub","cbz"))
    parser.add_argument("--import-html",type=Path)
    parser.add_argument("--import-edge",type=Path,help="Fichier JSON de l’extension Chromium (Edge/Chrome/Opera/Brave)")
    parser.add_argument("--partial",action="store_true")
    parser.add_argument("--permit-archive",action="store_true",help="confirme l'autorisation de conserver ces pages")
    parser.add_argument("--expect",type=int,default=0,help="nombre total attendu pour valider une collection importée")
    parser.add_argument("--check",action="store_true",help="contrôle qualité des chapitres (JSON)")
    parser.add_argument("--self-test",action="store_true",help="test du programme sans interface ni réseau")
    parser.add_argument("--self-test-report",type=Path,help="chemin du rapport du test interne")
    parser.add_argument("--ui-probe",action="store_true",help="test de demarrage tkinter, sans interface persistante")
    args=parser.parse_args()
    if args.self_test:
        payload = {"ok": bool(BeautifulSoup), "version": VERSION, "python": sys.version.split()[0]}
        if args.ui_probe:
            try:
                import tkinter as tk
                probe=tk.Tk()
                probe.withdraw()
                probe.update_idletasks()
                probe.destroy()
                payload["ui"]="ok"
            except Exception as exc:
                payload["ok"]=False
                payload["ui_error"]=str(exc)
        if args.self_test_report:
            args.self_test_report.parent.mkdir(parents=True,exist_ok=True)
            args.self_test_report.write_text(json.dumps(payload,ensure_ascii=False),encoding="utf-8")
        else:
            print(json.dumps(payload,ensure_ascii=False))
        if not payload["ok"]:
            sys.exit(2)
        return
    if args.import_edge and args.book == "Mon livre":
        from edge_bundle import FORMAT
        payload=json.loads(args.import_edge.read_text(encoding="utf-8-sig"))
        if payload.get("schema")==FORMAT:
            args.book=payload.get("book", args.book)
    root=ROOT/safe_slug(args.book)
    if args.gui or len(sys.argv)==1:
        build_gui()
        return
    if args.expect:
        if not 1 <= args.expect <= 20000:
            parser.error("--expect doit être entre 1 et 20 000")
        Catalog(root/"library.sqlite3").plan(args.book, [], args.mode, expected_end=args.expect)
    if args.import_html:
        print(import_html(args.book,args.import_html,root))
    if args.import_edge:
        from edge_bundle import import_edge_bundle
        print(json.dumps(import_edge_bundle(args.import_edge,root,expected_book=args.book),ensure_ascii=False))
    if args.check:
        print(json.dumps(inventory(Catalog(root/"library.sqlite3"),args.book),ensure_ascii=False,indent=2))
    if args.url:
        if not args.permit_archive:
            parser.error("Ajoute --permit-archive uniquement si la copie est autorisée")
        print(retrieve(args.book,root,args.url,args.mode,count=args.count,pattern=args.pattern,delay=max(1,args.delay),profile=json.loads(args.profile.read_text(encoding="utf-8")) if args.profile else None))
    if args.export:
        fn={"pdf":export_pdf,"epub":export_epub,"cbz":export_cbz}[args.export]
        dest=root/(safe_slug(args.book)+"."+args.export)
        print(fn(args.book,root,dest,allow_partial=args.partial))


if __name__=="__main__":
    main()
