"""One-button, fail-closed retrieval for sources with archive permission.

No WAF evasion. First qualifies three random chapter pages, then resumes
remaining chapters, audits every entry, and atomically publishes PDF/EPUB.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import random
import re
import zipfile
from pathlib import Path
from threading import Event
from typing import Callable

import bookharvester as b


def _atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temp, path)


def run_one_click(book: str, url: str, total: int, root: Path, *,
                  pattern: str = 'chapter-{n}/', delay: float = 2.0,
                  seed: int | None = None, authorized: bool = False,
                  stop: Event | None = None,
                  on_update: Callable[[dict], None] | None = None) -> dict:
    """Qualify random three then retrieve all. Never export an incomplete book.

    on_update receives structured messages, safe to enqueue from worker threads.
    """
    if not authorized:
        raise PermissionError('Autorisation de sauvegarde non confirmée pour cette source')
    b.check_url(url)
    if not isinstance(total, int) or not 3 <= total <= 20000:
        raise ValueError('Le nombre de chapitres doit être entre 3 et 20000')
    if '{n}' not in pattern:
        raise ValueError('Patron de chapitres invalide : {n} manquant')
    if not (0 <= delay <= 120):
        raise ValueError('Délai hors limites')
    if not book.strip():
        raise ValueError('Titre de livre manquant')

    emit = on_update or (lambda _msg: None)
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    seed = seed if seed is not None else random.SystemRandom().randint(1, 2**31 - 1)
    report = {
        'schema': 'bookharvester.oneclick.v1', 'version': b.VERSION,
        'book': book, 'source': b.canonical(url), 'expected': total,
        'seed': seed, 'sampled': [], 'sample_validated': 0,
        'collected': 0, 'complete': False, 'exports': {},
        'status': 'STARTED', 'diagnostic': '',
        'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    }
    path = root / 'last_oneclick_report.json'

    def publish(status: str, diagnostic: str = '') -> dict:
        report['status'] = status
        report['diagnostic'] = diagnostic
        report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        _atomic_json(path, report)
        emit({'kind': 'complete', 'status': status, 'message': diagnostic,
              'collected': report['collected'], 'expected': total})
        return dict(report)

    if stop is not None and stop.is_set():
        return publish('CANCELLED', 'Arrêt demandé avant le début')
    # Never silently mix validated chapters from another website under the same
    # book title / SQLite catalog. Older versions didn't persist source metadata.
    try:
        cat = b.Catalog(root / 'library.sqlite3')
        try:
            previous = cat.connection.execute('SELECT source FROM books WHERE book=?', (book,)).fetchone()
            if previous and previous[0] and b.canonical(previous[0]) != b.canonical(url):
                return publish('SOURCE_MISMATCH', 'Le titre contient déjà des chapitres provenant d’une autre source')
            entries = cat.chapters(book)
            if any(not row[1].startswith(b.canonical(url)) for row in entries):
                return publish('SOURCE_MISMATCH', 'Chapitres déjà enregistrés pour une autre URL')
            with cat.connection:
                cat.connection.execute('INSERT OR IGNORE INTO books(book,expected_end,source) VALUES(?,?,?)',
                                       (book,0,b.canonical(url)))
                cat.connection.execute('UPDATE books SET source=? WHERE book=?', (b.canonical(url),book))
        finally:
            cat.close()
    except Exception as exc:
        return publish('ERROR', f'Vérification de provenance : {exc}')
    emit({'kind': 'stage', 'status': 'SAMPLING', 'message': 'Validation de 3 chapitres aléatoires'})
    try:
        def event(line: str) -> None:
            match = re.search(r'Échantillon (\d+)\s*:\s*(\w+)', line)
            if match:
                emit({'kind': 'sample', 'chapter': int(match.group(1)), 'status': match.group(2)})
            else:
                emit({'kind': 'log', 'message': line})

        sample = b.sample_three_chapters(book, root, url, total, seed=seed,
                                         pattern=pattern, delay=delay, event=event)
        report['sampled'] = sample['sampled']
        report['sample_validated'] = sample['validated']
        if sample['status'] != 'SAMPLE_PASS' or sample['validated'] != 3 or sample.get('distinct_texts') != 3:
            report['blocked'] = sample.get('blocked', 0)
            reason = 'Restrictions du site détectées, aucune copie intégrale lancée' if sample.get('blocked', 0) else 'Chapitre invalide ou extraction impossible'
            return publish('ACCESS_BLOCKED' if sample.get('blocked', 0) else 'SAMPLE_FAILED', reason)
        if stop is not None and stop.is_set():
            return publish('CANCELLED', 'Arrêt demandé après les trois tests')

        emit({'kind': 'stage', 'status': 'DOWNLOADING', 'message': f'3 chapitres validés; collecte de {total} chapitres'})
        def log_event(message: str) -> None:
            match = re.search(r'Chapitre\s+(\d+)\s*:\s*(.*)', message)
            if match:
                number = int(match.group(1))
                state = match.group(2)
                state = 'validated' if 'validé' in state else ('downloading' if 'récupération' in state else 'error')
                emit({'kind': 'chapter', 'chapter': number, 'status': state, 'message': message})
            elif 'BLOCAGE chapitre' in message:
                emit({'kind': 'log', 'message': message})
            else:
                emit({'kind': 'log', 'message': message})

        result = b.retrieve(book, root, url, 'novel', count=total,
                            pattern=pattern, delay=delay, event=log_event, stop=stop)
        report['retrieval'] = result
        cat = b.Catalog(root / 'library.sqlite3')
        try:
            inv = b.inventory(cat, book)
        finally:
            cat.close()
        report['collected'] = inv['ok']
        report['inventory'] = inv
        emit({'kind': 'progress', 'collected': inv['ok'], 'expected': total})
        if stop is not None and stop.is_set():
            return publish('CANCELLED', 'Arrêt demandé ; les chapitres validés sont conservés')
        if result.get('blocked'):
            return publish('ACCESS_BLOCKED', 'Accès au site refusé pendant la collecte')
        if not inv['complete'] or inv['expected'] != total:
            return publish('INCOMPLETE', f"Collection incomplète : {inv['ok']}/{total}; PDF complet non créé")

        report['complete'] = True
        emit({'kind': 'stage', 'status': 'EXPORTING', 'message': 'Contrôle et génération EPUB + PDF'})
        prefix = b.safe_slug(book)
        pdf = root / (prefix + '.pdf')
        epub = root / (prefix + '.epub')
        temp_pdf = root / (prefix + '.temporary.pdf')
        temp_epub = root / (prefix + '.temporary.epub')
        try:
            b.export_epub(book, root, temp_epub)
            with zipfile.ZipFile(temp_epub, 'r') as z:
                chapters = [n for n in z.namelist() if re.fullmatch(r'OEBPS/c\d{5}\.xhtml', n)]
                if len(chapters) != total or z.testzip() is not None:
                    raise ValueError('EPUB corrompu ou incomplet')
            b.export_pdf(book, root, temp_pdf)
            if temp_pdf.stat().st_size < 800 or not temp_pdf.open('rb').read(5) == b'%PDF-':
                raise ValueError('PDF manquant ou invalide')
            # Final names appear only after both exports have been checked.
            os.replace(temp_epub, epub)
            os.replace(temp_pdf, pdf)
        except Exception:
            temp_epub.unlink(missing_ok=True)
            temp_pdf.unlink(missing_ok=True)
            raise
        report['exports'] = {'pdf': str(pdf), 'epub': str(epub)}
        emit({'kind': 'progress', 'collected': total, 'expected': total})
        return publish('COMPLETE', f'{total}/{total} chapitres vérifiés; EPUB et PDF créés')
    except Exception as exc:
        return publish('ERROR', f'{type(exc).__name__} : {str(exc)[:250]}')
