/* BookHarvester Reader V1.2. One origin permission per user-selected source.
   No captcha solving / bot evasion / paywall bypass / background scraping of other domains.
   All chapter data is held in Edge storage.local until user exports it. */
const J='bh_job_v1', C='bh_chapters_v1';
const busy = new Set();
function buildUrl(pattern,n) {
  if (typeof pattern!=='string' || !pattern.includes('{n}')) throw Error('Patron URL sans {n}');
  const url = new URL(pattern.replaceAll('{n}',String(n)));
  if (!['https:','http:'].includes(url.protocol)) throw Error('URL non HTTP(S)');
  return url.toString();
}
function cleanOrigin(url){return new URL(url).origin;}
async function setJob(job) {await chrome.storage.local.set({[J]:job});}
async function getState(){return await chrome.storage.local.get([J,C]);}
async function recordError(job,msg){job.state='paused';job.error=String(msg).slice(0,300);job.changedAt=Date.now();await setJob(job);}
async function step(tabId) {
  if (busy.has(tabId))return;
  busy.add(tabId);
  try {
    const state=await getState();const job=state[J];
    if(!job || job.state!=='running'||job.tabId!==tabId)return;
    if(job.next>job.last){job.state='done';await setJob(job);return;}
    const expected=buildUrl(job.pattern,job.next),actual=(await chrome.tabs.get(tabId)).url || '';
    if(cleanOrigin(expected)!==job.origin){await recordError(job,'Origine du chapitre différente du site autorisé');return;}
    if(actual!==expected){await chrome.tabs.update(tabId,{url:expected});return;}
    const injected=await chrome.scripting.executeScript({target:{tabId},files:['reader.js']});
    const captures=await chrome.scripting.executeScript({target:{tabId},func:(css)=>globalThis.BH_READ_PAGE(css),args:[job.selectors]});
    const content=captures[0]?.result;
    if(!content?.ok){await recordError(job,content?.error||'Page non lisible');return;}
    const data=state[C]||[];
    const previous=data.find(x=>x.number===job.next);
    if(previous && previous.text!==content.text){await recordError(job,'Conflit de texte pour le chapitre '+job.next);return;}
    if(!previous) data.push({number:job.next,url:expected,title:content.title,text:content.text});
    await chrome.storage.local.set({[C]:data});
    job.doneCount=data.length;
    job.error='';
    if (Array.isArray(job.sequence)) {
      const completed=new Set(data.map(x=>x.number));
      const stillMissing=job.sequence.find(n=>!completed.has(n));
      job.next=stillMissing===undefined ? job.last+1 : stillMissing;
    } else {
      job.next++;
    }
    job.changedAt=Date.now();
    if(job.next>job.last){job.state='done';await setJob(job);return;}
    await setJob(job);
    // This is controlled by the user. Keep a delay between navigations.
    await new Promise(resolve=>setTimeout(resolve, Math.max(1500,Math.min(12000,job.delayMs||2000))));
    const now=(await getState())[J];
    if(now?.state==='running'&&now?.next===job.next)await chrome.tabs.update(tabId,{url:buildUrl(job.pattern,job.next)});
  }catch(e){const j=(await getState())[J];if(j)await recordError(j,e?.message||'Erreur navigateur');}
  finally{busy.delete(tabId);}
}
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='complete')step(tabId);});
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  (async()=>{
    const existing=await getState();
    if(message.type==='START'){
      const p=message.params||{};
      const start=Number(p.first),last=Number(p.last),expected=Number(p.expected);
      if(!Number.isInteger(start)||!Number.isInteger(last)||!Number.isInteger(expected)||start<1||last<start||last>expected||expected>20000)throw Error('Plage de chapitres incorrecte');
      const sequence = p.samples === undefined ? null : p.samples;
      if (sequence !== null && (!Array.isArray(sequence) || sequence.length!==3 ||
          new Set(sequence).size!==3 || sequence.some(n=>!Number.isInteger(n)||n<1||n>expected)))
        throw Error('Le test doit contenir exactement trois chapitres distincts et valides');
      const firstURL=buildUrl(p.pattern,sequence?sequence[0]:start);const origin=cleanOrigin(firstURL);
      const tab=await chrome.tabs.get(p.tabId);
      if(!tab||!tab.url||cleanOrigin(tab.url)!==origin)throw Error('Ouvre la page du même site dans le navigateur avant de lancer');
      const sameBook = existing[J] && existing[J].book===p.book.trim() && existing[J].origin===origin && existing[J].pattern===p.pattern;
      const saved = sameBook ? (existing[C]||[]) : [];
      const known = new Set(saved.map(c=>c.number));
      const requested=sequence || Array.from({length:last-start+1},(_,i)=>start+i);
      const firstMissing = requested.find(n=>!known.has(n));
      if (firstMissing===undefined) throw Error('Tous les chapitres demandés sont déjà sauvegardés');
      const job={book:p.book.trim(),origin,pattern:p.pattern,first:sequence?Math.min(...sequence):start,last:sequence?Math.max(...sequence):last,
                 sequence,expected_end:expected,next:firstMissing,tabId:p.tabId,state:'running',doneCount:saved.length,error:'',
                 delayMs:Math.max(1500,Number(p.delayMs)||2000),selectors:p.selectors||[],changedAt:Date.now()};
      if(!job.book || job.book.length>180)throw Error('Titre incorrect');
      await chrome.storage.local.set({[J]:job,[C]:saved});
      await chrome.tabs.update(tab.id,{url:buildUrl(p.pattern,firstMissing)});respond({ok:true});
    }else if(message.type==='STOP'){
      const job=existing[J];if(job){job.state='paused';job.error='Arrêt demandé';await setJob(job);}respond({ok:true});
    }else if(message.type==='RESUME'){
      const job=existing[J];if(!job)throw Error('Aucune collecte');
      if(job.next>job.last)throw Error('Collecte terminée');
      job.state='running';job.error='';job.tabId=message.tabId;await setJob(job);
      await chrome.tabs.update(job.tabId,{url:buildUrl(job.pattern,job.next)});respond({ok:true});
    }else if(message.type==='STATUS'){
      respond({ok:true,job:existing[J]||null,chapters:(existing[C]||[]).length});
    }else throw Error('Commande inconnue');
  })().catch(e=>respond({ok:false,error:String(e.message||e)}));
  return true;
});
